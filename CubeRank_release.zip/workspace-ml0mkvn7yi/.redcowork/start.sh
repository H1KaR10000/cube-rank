#!/bin/sh
# .redcowork/start.sh — STATIC_SITE 静态站点预览恢复脚本（幂等，可重复执行）
# 工程路径 /workspace，端口 3030，纯静态（无后端 / 无 DB），python3 http.server 起服。

set -u

PROJECT=/workspace
PORT=3030
LOG_DIR="$PROJECT/.logs"
LOG="$LOG_DIR/app.log"

# 1) 注销旧预览注册、停旧日志 daemon（幂等）
redcowork-preview stop >/dev/null 2>&1 || true
redcowork-log stop >/dev/null 2>&1 || true

# 2) 停掉占用端口的旧 http.server（镜像无 ps/pkill，用 python 扫 /proc 精确匹配后 SIGKILL）
python3 - "$PORT" <<'PY'
import os, signal, time, sys
port = sys.argv[1]
needle = "http.server %s" % port
for pid in os.listdir("/proc"):
    if not pid.isdigit():
        continue
    try:
        with open("/proc/%s/cmdline" % pid, "rb") as f:
            cmd = f.read().decode("utf-8", "replace").replace("\x00", " ")
    except Exception:
        continue
    if needle in cmd:
        try:
            os.kill(int(pid), signal.SIGKILL)
        except Exception:
            pass
time.sleep(1)
PY

# 3) 确认端口已释放；仍占用则中止（避免死端口空注册）
if python3 - "$PORT" <<'PY'
import sys, socket
s = socket.socket()
s.settimeout(1)
sys.exit(0 if s.connect_ex(("127.0.0.1", int(sys.argv[1]))) == 0 else 1)
PY
then
  echo "[ABORT] port $PORT still occupied after cleanup" >&2
  exit 1
fi

# 4) 后台起静态 server
mkdir -p "$LOG_DIR"
nohup python3 -m http.server "$PORT" --bind 0.0.0.0 --directory "$PROJECT" > "$LOG" 2>&1 &
sleep 2

# 5) 端到端自检：首页 + 页面真实依赖的静态资源，任一失败即退出（不注册）
curl -fsS "http://127.0.0.1:$PORT/" -o /dev/null -w "index -> HTTP %{http_code}\n" || { echo "[FAIL] index" >&2; exit 1; }
curl -fsS "http://127.0.0.1:$PORT/css/style.css" -o /dev/null || { echo "[FAIL] css/style.css" >&2; exit 1; }
curl -fsS "http://127.0.0.1:$PORT/js/app.js" -o /dev/null || { echo "[FAIL] js/app.js" >&2; exit 1; }
curl -fsS "http://127.0.0.1:$PORT/js/data.js" -o /dev/null || { echo "[FAIL] js/data.js" >&2; exit 1; }

# 6) 注册预览 + 日志滚动 daemon
redcowork-preview start "$PORT" "$PROJECT"
redcowork-log start

echo "[OK] recovered: $PROJECT on port $PORT"
