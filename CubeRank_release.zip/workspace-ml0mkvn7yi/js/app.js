/* =========================================================
 * 应用层：hash 路由、页面渲染、排行榜 FLIP 动效、选手弹窗
 * 主题切换（深色/浅色）、惩罚录入（+2 / DNF 按钮）、回车跳格
 * 选手库（跨比赛聚合）+ 选手主页
 * ========================================================= */
(function () {
  'use strict';

  const D = window.CubeData;
  D.load();

  const $app = document.getElementById('app');
  const $modalRoot = document.getElementById('modal-root');
  const $toastRoot = document.getElementById('toast-root');

  /* ---------------- 主题（深色 / 浅色） ---------------- */
  const THEME_KEY = 'sjtu-cube-weekly-theme';

  function applyTheme(t) {
    if (t === 'light') document.documentElement.dataset.theme = 'light';
    else delete document.documentElement.dataset.theme;
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', t === 'light' ? '#eef2f7' : '#0b1020');
  }

  let theme = 'dark';
  try { if (localStorage.getItem(THEME_KEY) === 'light') theme = 'light'; } catch (e) { /* 忽略 */ }
  applyTheme(theme);

  const themeBtn = document.createElement('button');
  themeBtn.className = 'theme-btn';
  themeBtn.title = '切换深色 / 浅色主题';
  document.body.appendChild(themeBtn);
  const syncThemeBtn = () => { themeBtn.textContent = theme === 'dark' ? '☀️' : '🌙'; };
  syncThemeBtn();
  themeBtn.addEventListener('click', () => {
    theme = theme === 'dark' ? 'light' : 'dark';
    try { localStorage.setItem(THEME_KEY, theme); } catch (e) { /* 忽略 */ }
    applyTheme(theme);
    syncThemeBtn();
  });

  /* ---------------- 工具 ---------------- */
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  }[c]));
  /* 属性选择器转义（CSS.escape 兜底） */
  const cssEscape = (s) => (window.CSS && CSS.escape
    ? CSS.escape(s)
    : String(s).replace(/[^a-zA-Z0-9_\u00A0-\uFFFF-]/g, (c) => '\\' + c));
  const fmtTime = (val, pen) => D.fmtTime(val, pen);
  const fmt2 = (x) => D.fmt2(x);
  /* 2026-09-01 → 2026.09.01 */
  const dotted = (d) => String(d).replace(/-/g, '.');

  function toast(msg) {
    const el = document.createElement('div');
    el.className = 'toast';
    el.textContent = msg;
    $toastRoot.appendChild(el);
    setTimeout(() => el.classList.add('out'), 2300);
    setTimeout(() => el.remove(), 2800);
  }

  function pad(n) { return String(n).padStart(2, '0'); }
  function todayStr() {
    const d = new Date();
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  }

  /* ---------------- 路由 ---------------- */
  function parseHash() {
    const raw = location.hash.replace(/^#/, '');
    const parts = raw.split('/').filter(Boolean).map((s) => {
      try { return decodeURIComponent(s); } catch (e) { return s; }
    });
    if (parts[0] === 'comp' && parts[1]) {
      if (parts[2] === 'event' && parts[3]) {
        return { page: 'event', compId: parts[1], evId: parts[3] };
      }
      return { page: 'comp', compId: parts[1] };
    }
    if (parts[0] === 'players') return { page: 'players' };
    if (parts[0] === 'records') return { page: 'records' };
    if (parts[0] === 'pk') {
      return parts.length >= 3
        ? { page: 'pk', left: parts[1], right: parts[2] }
        : { page: 'pk' };
    }
    if (parts[0] === 'player' && parts[1]) {
      return { page: 'player', name: parts.slice(1).join('/') };
    }
    return { page: 'home' };
  }

  window.addEventListener('hashchange', render);

  function render() {
    const r = parseHash();
    if (r.page === 'comp') renderComp(r.compId);
    else if (r.page === 'event') renderEvent(r.compId, r.evId);
    else if (r.page === 'players') renderPlayers();
    else if (r.page === 'records') renderRecords();
    else if (r.page === 'pk') renderPK(r.left, r.right);
    else if (r.page === 'player') renderPlayer(r.name);
    else renderHome();
  }

  function notFound() {
    $app.innerHTML = `
      <main class="container">
        <div class="card empty-card">
          <p>🤔 页面不存在或已被删除</p>
          <a class="btn primary" href="#/">返回首页</a>
        </div>
      </main>`;
  }

  /* ---------------- 通用：确认弹窗 ---------------- */
  function confirmDialog({ title, text, okText = '确认', danger = false }) {
    return new Promise((resolve) => {
      $modalRoot.innerHTML = `
        <div class="modal-overlay">
          <div class="modal small">
            <h3 class="m-title">${esc(title)}</h3>
            <div class="m-text">${text}</div>
            <div class="m-actions">
              <button class="btn ghost" id="cd-cancel">取消</button>
              <button class="btn ${danger ? 'danger' : 'primary'}" id="cd-ok">${esc(okText)}</button>
            </div>
          </div>
        </div>`;
      const done = (v) => {
        $modalRoot.innerHTML = '';
        document.removeEventListener('keydown', onKey);
        resolve(v);
      };
      const onKey = (e) => { if (e.key === 'Escape') done(false); };
      document.addEventListener('keydown', onKey);
      document.getElementById('cd-cancel').addEventListener('click', () => done(false));
      document.getElementById('cd-ok').addEventListener('click', () => done(true));
    });
  }

  /* ================= 首页 ================= */
  /* ---------------- 站点 Logo：齿轮 × 魔方单面（WCA 标准六色） ---------------- */
  const LOGO_SVG = (() => {
    const C = { W: '#ffffff', Y: '#ffd500', R: '#b71234', O: '#ff5800', B: '#0046ad', G: '#009b48' };
    /* 八齿齿轮轮廓（齿牙亮于底盘，层次分明） */
    const teeth = [0, 45, 90, 135, 180, 225, 270, 315].map((k) =>
      `<rect x="46.5" y="2.5" width="7" height="10" rx="2" fill="#818cf8" transform="rotate(${k} 50 50)"/>`).join('');
    /* 齿轮内嵌 3×3 六色贴纸面（打乱排布，四周留呼吸感） */
    const F = ['Y', 'R', 'W', 'O', 'B', 'G', 'W', 'Y', 'R'];
    let cells = '';
    let i = 0;
    [27.5, 43.75, 60].forEach((y) => {
      [27.5, 43.75, 60].forEach((x) => {
        cells += `<rect x="${x}" y="${y}" width="12.5" height="12.5" rx="2.8" fill="${C[F[i++]]}"/>`;
      });
    });
    return `
      <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
        <g fill="#1f2950">${teeth}<circle cx="50" cy="50" r="38" fill="#1f2950"/></g>
        ${cells}
      </svg>`;
  })();

  /* ================= 首页 ================= */
  let homeMode = 'manual';   /* 新建比赛模式：manual 手动 / import Excel 导入 */

  function renderHome() {
    const comps = D.state().competitions;
    const nextN = comps.length + 1;

    const cards = comps.map((c) => {
      const total = D.compPlayerNames(c).size;
      const evChips = c.events.map((id) => {
        const ev = D.eventById(id);
        return `<span class="chip" style="--c:${ev.color}">${ev.icon} ${esc(ev.name)}</span>`;
      }).join('');
      return `
        <div class="card comp-card">
          <div class="comp-top" data-open="#/comp/${c.id}">
            <div class="comp-info">
              <h3>${esc(c.name)}</h3>
              <p class="sub">${esc(c.date)} · ${total} 位选手</p>
            </div>
            <div class="comp-badges">
              ${c.ended
                ? '<span class="badge done sm">🔒 已结束</span>'
                : '<span class="badge live sm"><i></i>进行中</span>'}
            </div>
          </div>
          <div class="comp-bottom">
            <div class="chips">${evChips}</div>
            <button class="icon-btn" data-del="${c.id}" title="删除比赛">🗑</button>
          </div>
        </div>`;
    }).join('');

    $app.innerHTML = `
      <header class="hero">
        <div class="hero-inner">
          <div class="logo">${LOGO_SVG}</div>
          <div class="hero-text">
            <h1>CubeRank</h1>
            <p>SJTU 魔方周赛 · 成绩录入 · 实时排行 · 赛果导出</p>
          </div>
          <div class="hero-links">
            <a class="btn ghost hero-link" href="#/players">👤 选手</a>
            <a class="btn ghost hero-link" href="#/records">📜 纪录</a>
            <a class="btn ghost hero-link" href="#/pk">⚔️ PK</a>
          </div>
        </div>
      </header>
      <main class="container">
        <section class="card">
          <h3 class="card-title">📅 新建比赛</h3>
          <div class="seg" id="home-mode">
            <button type="button" class="seg-btn${homeMode === 'manual' ? ' on' : ''}" data-hmode="manual">📝 手动创建</button>
            <button type="button" class="seg-btn${homeMode === 'import' ? ' on' : ''}" data-hmode="import">📥 Excel 导入</button>
          </div>
          <form id="create-form" novalidate${homeMode === 'manual' ? '' : ' hidden'}>
            <div class="create-grid">
              <div class="field">
                <label for="cf-name">比赛名称</label>
                <input id="cf-name" value="第 ${nextN} 次周赛" maxlength="40" autocomplete="off">
              </div>
              <div class="field">
                <label for="cf-date">比赛日期</label>
                <input id="cf-date" type="date" value="${todayStr()}">
              </div>
            </div>
            <div class="field">
              <label>比赛项目（至少勾选一项）</label>
              <div class="event-checks">
                ${D.EVENTS.map((ev) => `
                  <label class="event-check">
                    <input type="checkbox" value="${ev.id}"${ev.id === '3x3' ? ' checked' : ''}>
                    <span class="chip lg" style="--c:${ev.color}">${ev.icon} ${esc(ev.name)}</span>
                  </label>`).join('')}
              </div>
            </div>
            <div class="form-error" id="cf-error"></div>
            <button class="btn primary" type="submit">🚀 创建比赛</button>
          </form>

          <form id="import-form" novalidate${homeMode === 'import' ? '' : ' hidden'}>
            <div class="create-grid">
              <div class="field">
                <label for="if-name">比赛名称</label>
                <input id="if-name" value="第 ${nextN} 次周赛" maxlength="40" autocomplete="off">
              </div>
              <div class="field">
                <label for="if-date">比赛日期</label>
                <input id="if-date" type="date" value="${todayStr()}">
              </div>
            </div>
            <div class="field">
              <label for="if-file">赛果 Excel 文件（.xlsx / .xls）</label>
              <input type="file" id="if-file" accept=".xlsx,.xls">
            </div>
            <details class="fmt-help">
              <summary>📋 Excel 格式要求（点开查看详细说明）</summary>
              <ul>
                <li>每个<b>工作表名</b>须与项目名完全相同：${D.EVENTS.map((ev) => esc(ev.name)).join('、')}</li>
                <li>表内<b>每行</b> = 一位选手：<b>第 1 列为姓名</b>，其后为该项目的全部还原成绩（五次制 5 个、三次制 3 个），<b>无表头</b></li>
                <li>成绩写法：<code>8.62</code>（秒）、<code>1:01.59</code>（分:秒）、<code>DNF</code>、<code>9.58+</code>（+2 惩罚）均可，数字或文本单元格都行</li>
                <li>单次、平均、名次由系统自动计算，无需在 Excel 中先行计算</li>
                <li>无需导入的项目不建对应工作表即可，导入的项目按默认顺序排列</li>
              </ul>
            </details>
            <div class="form-error" id="if-error"></div>
            <div class="import-preview" id="if-preview" hidden></div>
            <button class="btn primary" type="submit" id="if-submit" disabled>📥 解析文件后创建比赛</button>
          </form>
        </section>

        <section class="home-list">
          <h3 class="section-title">🏆 比赛列表</h3>
          ${comps.length
            ? `<div class="comp-list">${cards}</div>`
            : '<div class="empty">还没有比赛，先在上面创建一场吧 🎲</div>'}
        </section>

        <footer class="site-foot">数据保存在本浏览器（localStorage）中 · CubeRank · SJTU 魔方周赛成绩管理系统</footer>
      </main>`;

    /* 新建比赛 */
    document.getElementById('create-form').addEventListener('submit', (e) => {
      e.preventDefault();
      const errBox = document.getElementById('cf-error');
      errBox.textContent = '';
      const name = document.getElementById('cf-name').value.trim();
      const date = document.getElementById('cf-date').value || todayStr();
      const evs = [...document.querySelectorAll('.event-check input:checked')].map((i) => i.value);
      const errs = [];
      if (!name) errs.push('请填写比赛名称');
      if (!evs.length) errs.push('请至少勾选一个比赛项目');
      if (errs.length) {
        errBox.innerHTML = errs.map((s) => '• ' + esc(s)).join('<br>');
        return;
      }
      const comp = D.createCompetition({ name, date, events: evs });
      toast(`已创建「${comp.name}」`);
      location.hash = `#/comp/${comp.id}`;
    });

    /* ---------- Excel 赛果导入 ---------- */
    let pendingImport = null;
    const ifErr = document.getElementById('if-error');
    const ifPrev = document.getElementById('if-preview');
    const ifBtn = document.getElementById('if-submit');

    document.querySelectorAll('#home-mode [data-hmode]').forEach((b) => {
      b.addEventListener('click', () => {
        homeMode = b.dataset.hmode;
        document.querySelectorAll('#home-mode [data-hmode]').forEach((x) => x.classList.toggle('on', x === b));
        document.getElementById('create-form').hidden = homeMode !== 'manual';
        document.getElementById('import-form').hidden = homeMode !== 'import';
      });
    });

    document.getElementById('if-file').addEventListener('change', async (e) => {
      const file = e.target.files && e.target.files[0];
      ifErr.innerHTML = '';
      ifPrev.hidden = true;
      ifBtn.disabled = true;
      pendingImport = null;
      if (!file) { ifBtn.textContent = '📥 解析文件后创建比赛'; return; }
      ifBtn.textContent = '⏳ 解析中…';
      try {
        const buf = await file.arrayBuffer();
        const res = window.CubeImport.parseWorkbook(buf);
        if (!res.ok) {
          const shown = res.errors.slice(0, 8).map((s) => '• ' + esc(s)).join('<br>');
          const more = res.errors.length > 8
            ? `<br>• …等共 ${res.errors.length} 个问题，请修正文件后重新上传` : '';
          ifErr.innerHTML = shown + more;
          ifBtn.textContent = '📥 解析文件后创建比赛';
          return;
        }
        const nPlayers = new Set(res.sheets.flatMap((s) => s.rows.map((r) => r.name))).size;
        const nRows = res.sheets.reduce((s, x) => s + x.rows.length, 0);
        ifPrev.hidden = false;
        ifPrev.innerHTML = `
          <div class="ip-line"><b>✅ 文件解析成功</b></div>
          <div class="ip-line">${res.sheets.length} 个项目 · ${nPlayers} 位选手 · ${nRows} 条成绩记录</div>
          <div class="ip-chips">${res.sheets.map((s) => {
            const ev = D.eventById(s.evId);
            return `<span class="chip sm" style="--c:${ev.color}">${ev.icon} ${esc(s.evName)} × ${s.rows.length}</span>`;
          }).join('')}</div>`;
        pendingImport = res;
        ifBtn.disabled = false;
        ifBtn.textContent = '🚀 创建比赛并导入成绩';
      } catch (err) {
        ifErr.textContent = '• 读取文件失败：' + (err && err.message ? esc(err.message) : '未知错误');
        ifBtn.textContent = '📥 解析文件后创建比赛';
      }
    });

    document.getElementById('import-form').addEventListener('submit', (e) => {
      e.preventDefault();
      ifErr.textContent = '';
      const name = document.getElementById('if-name').value.trim();
      const date = document.getElementById('if-date').value || todayStr();
      const errs = [];
      if (!name) errs.push('请填写比赛名称');
      if (!pendingImport || !pendingImport.ok) errs.push('请先上传并成功解析赛果 Excel 文件');
      if (errs.length) {
        ifErr.innerHTML = errs.map((s) => '• ' + esc(s)).join('<br>');
        return;
      }
      const comp = D.createCompetition({ name, date, events: pendingImport.sheets.map((s) => s.evId) });
      pendingImport.sheets.forEach((s) => s.rows.forEach((r) => D.upsertRecord(comp, s.evId, r.name, r.entries)));
      const n = pendingImport.sheets.reduce((s, x) => s + x.rows.length, 0);
      toast(`已导入「${comp.name}」· ${pendingImport.sheets.length} 个项目 · ${n} 条成绩`);
      location.hash = `#/comp/${comp.id}`;
    });
  }

  /* ================= 比赛总览页 ================= */
  function renderComp(compId) {
    const comp = D.getComp(compId);
    if (!comp) return notFound();

    const eventCards = comp.events.map((evId) => {
      const ev = D.eventById(evId);
      const rows = D.rankList(comp, evId);
      const leader = rows[0];
      const recCount = (comp.results[evId] || []).length;
      return `
        <div class="card ev-card" draggable="true" data-open="#/comp/${comp.id}/event/${evId}"
          data-ev="${evId}" style="--c:${ev.color}" title="点击进入 · 拖动卡片排序">
          <div class="ev-card-top">
            <span class="ev-icon">${ev.icon}</span>
            <div class="ev-info">
              <h3>${esc(ev.name)}</h3>
              <p class="sub">${rows.length} 位选手</p>
            </div>
            <div class="ev-ops">
              <span class="icon-btn drag-handle" title="按住拖动卡片可排序">⠿</span>
              <button class="icon-btn del" data-evdel="${evId}" title="删除该项目">🗑</button>
              <span class="go">进入 →</span>
            </div>
          </div>
          ${leader
            ? `<div class="ev-leader">🥇 <b>${esc(leader.name)}</b>
               <span class="mono dim">${ev.attempts === 3 ? 'Ao3' : 'Ao5'} ${esc(leader.ao5Disp)} · 最好 ${esc(leader.bestDisp)}</span></div>`
            : '<div class="ev-leader dim">暂无成绩，点击进入录入</div>'}
        </div>`;
    }).join('');

    /* 比赛进行中可追加项目 */
    const remaining = comp.ended
      ? []
      : D.EVENTS.filter((ev) => !comp.events.includes(ev.id));
    const addCard = remaining.length ? `
      <div class="card ev-add">
        <button class="ev-add-btn" id="ev-add-btn" title="比赛进行中可随时增加项目">＋ 添加项目</button>
        <div class="ev-picker" id="ev-picker" hidden>
          ${remaining.map((ev) => `
            <button class="ev-pick" data-ev="${ev.id}" style="--c:${ev.color}">
              ${ev.icon}<span>${esc(ev.name)}</span>
            </button>`).join('')}
        </div>
      </div>` : '';

    const exportPanel = comp.ended ? `
      <section class="card end-panel">
        <h3 class="card-title">📦 赛果导出</h3>
        <p class="sub" style="margin-bottom:14px">分项目导出，支持 Excel 与 PDF</p>
        <div class="export-rows">
          ${comp.events.map((evId) => {
            const ev = D.eventById(evId);
            return `
            <div class="export-row">
              <span class="chip" style="--c:${ev.color}">${ev.icon} ${esc(ev.name)}</span>
              <span class="flex-grow"></span>
              <button class="btn ghost" data-x="excel" data-ev="${evId}">📊 Excel</button>
              <button class="btn ghost" data-x="pdf" data-ev="${evId}">📄 PDF</button>
            </div>`;
          }).join('')}
        </div>
        <div class="export-all">
          <button class="btn primary" data-x="excel-all">📊 导出全部 Excel（分项目 Sheet）</button>
          <button class="btn primary" data-x="pdf-all">📄 导出全部 PDF（分项目分页）</button>
        </div>
        <div class="end-foot">
          <button class="linklike" data-x="reopen">↩ 重新开启比赛（继续录入成绩）</button>
        </div>
      </section>` : '';

    $app.innerHTML = `
      <main class="container">
        <nav class="crumbs">
          <a href="#/">首页</a><span>/</span><b>${esc(comp.name)}</b>
        </nav>
        <header class="page-head">
          <div class="head-info">
            <h2>${esc(comp.name)}</h2>
            <p class="sub">${esc(comp.date)} · ${comp.events.map((id) => D.eventById(id).name).join(' / ')}</p>
          </div>
          <div class="head-right">
            ${comp.ended
              ? '<span class="badge done">🔒 已结束</span>'
              : `<span class="badge live"><i></i>进行中</span>
                 <button class="btn primary" id="end-btn">🏁 结束比赛</button>`}
          </div>
        </header>

        <div class="ev-grid">${eventCards}${addCard}</div>
        ${exportPanel}
      </main>`;

    /* ---------- 项目卡片：拖拽排序 ---------- */
    const grid = $app.querySelector('.ev-grid');
    if (grid) {
      let dragEl = null;
      grid.addEventListener('dragstart', (e) => {
        const card = e.target.closest('.ev-card');
        if (!card) return;
        dragEl = card;
        card.classList.add('dragging');
        e.dataTransfer.effectAllowed = 'move';
        e.dataTransfer.setData('text/plain', card.dataset.ev);
      });
      grid.addEventListener('dragover', (e) => {
        if (!dragEl) return;
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
        const over = e.target.closest('.ev-card');
        if (!over || over === dragEl) return;
        const rect = over.getBoundingClientRect();
        const before = (e.clientX - rect.left) < rect.width / 2;
        grid.insertBefore(dragEl, before ? over : over.nextElementSibling);
      });
      grid.addEventListener('drop', (e) => e.preventDefault());
      grid.addEventListener('dragend', () => {
        if (!dragEl) return;
        dragEl.classList.remove('dragging');
        dragEl = null;
        const ids = [...grid.querySelectorAll('.ev-card[data-ev]')].map((c) => c.dataset.ev);
        if (ids.join() !== comp.events.join() && D.moveEvents(comp, ids)) {
          toast('项目顺序已更新');
        }
      });
    }

    /* ---------- 项目卡片：删除项目（二次确认，连带成绩） ---------- */
    $app.querySelectorAll('[data-evdel]').forEach((b) => {
      b.addEventListener('click', async (e) => {
        e.stopPropagation();
        e.preventDefault();
        const evId = b.dataset.evdel;
        const ev = D.eventById(evId);
        const n = (comp.results[evId] || []).length;
        const ok = await confirmDialog({
          title: '删除项目',
          text: `将从「<b>${esc(comp.name)}</b>」中删除 <b>${esc(ev.name)}</b> 项目`
            + (n ? `，以及 <b>${n} 位选手</b> 在该项目的全部成绩` : '')
            + '。<br>删除后无法恢复，确定吗？',
          okText: '删除项目',
          danger: true,
        });
        if (!ok) return;
        D.removeEvent(comp, evId);
        toast(`已删除「${ev.name}」项目`);
        renderComp(comp.id);
      });
    });

    /* 添加项目（比赛进行中） */
    const addBtn = document.getElementById('ev-add-btn');
    if (addBtn) {
      addBtn.addEventListener('click', () => {
        const picker = document.getElementById('ev-picker');
        picker.hidden = !picker.hidden;
        addBtn.textContent = picker.hidden ? '＋ 添加项目' : '✕ 收起';
      });
      $app.querySelectorAll('.ev-pick').forEach((b) => {
        b.addEventListener('click', () => {
          const evId = b.dataset.ev;
          if (D.addEvent(comp, evId)) {
            toast(`已添加「${D.eventById(evId).name}」项目`);
            renderComp(comp.id);
          }
        });
      });
    }

    /* 结束比赛 */
    const endBtn = document.getElementById('end-btn');
    if (endBtn) {
      endBtn.addEventListener('click', async () => {
        const ok = await confirmDialog({
          title: '结束比赛',
          text: `结束后「${esc(comp.name)}」将<b>锁定成绩录入</b>，同时开放赛果导出。<br>确定要结束吗？`,
          okText: '结束并锁定',
        });
        if (!ok) return;
        D.endCompetition(comp);
        toast('比赛已结束，可导出赛果 📦');
        renderComp(comp.id);
      });
    }

    /* 导出 / 重开 */
    $app.querySelectorAll('[data-x]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        const act = btn.dataset.x;
        const evId = btn.dataset.ev;
        try {
          if (act === 'excel') { CubeExport.eventExcel(comp, evId); toast('Excel 已导出 📊'); }
          else if (act === 'pdf') { CubeExport.eventPDF(comp, evId); toast('PDF 已导出 📄'); }
          else if (act === 'excel-all') { CubeExport.allExcel(comp); toast('全部赛果 Excel 已导出 📊'); }
          else if (act === 'pdf-all') { CubeExport.allPDF(comp); toast('全部赛果 PDF 已导出 📄'); }
          else if (act === 'reopen') {
            const ok = await confirmDialog({
              title: '重新开启比赛',
              text: '重新开启后可继续录入成绩。确定吗？',
              okText: '重新开启',
            });
            if (!ok) return;
            D.reopenCompetition(comp);
            toast('比赛已重新开启');
            renderComp(comp.id);
          }
        } catch (err) {
          console.error(err);
          toast('导出失败：' + (err && err.message ? err.message : '未知错误'));
        }
      });
    });
  }

  /* ================= 项目页（录入 + 排行榜） ================= */
  function renderEvent(compId, evId) {
    const comp = D.getComp(compId);
    const ev = D.eventById(evId);
    if (!comp || !ev || !comp.events.includes(evId)) return notFound();

    let editingName = null;   /* null = 新录入 */
    let lastRanks = null;     /* 上一次刷新时的名次快照，用于升降动效 */

    /* 项目计次与排名口径：3 次制项目（6x6/7x7/4bld/5bld/3bld）只统计三次；
       6x6/7x7 平均 = 三次直接平均（不去头去尾）；盲拧三项排名先比单次最好 */
    const N = ev.attempts || 5;
    const AVG = N === 3 ? 'Ao3' : 'Ao5';
    const boardNote = ev.rankMode === 'single'
      ? `三次制 · 先比单次最好，相同再比平均（Ao3 = 三次直接平均，任一次 DNF 平均记 DNF）`
      : N === 3
        ? `三次制 · Ao3 = 三次直接平均（不去头去尾），任一次 DNF 记 DNF；先比 Ao3，相同比单次最好`
        : `先比 Ao5，相同比单次最好；Ao5 无效（DNF×2）排最后`;

    $app.innerHTML = `
      <main class="container">
        <nav class="crumbs">
          <a href="#/">首页</a><span>/</span>
          <a href="#/comp/${comp.id}">${esc(comp.name)}</a><span>/</span>
          <b>${ev.icon} ${esc(ev.name)}</b>
        </nav>

        <header class="page-head">
          <div class="head-info">
            <h2>${ev.icon} ${esc(ev.name)}</h2>
            <p class="sub">${esc(comp.name)} · ${esc(comp.date)}</p>
          </div>
          <div class="head-right">
            ${comp.ended
              ? '<span class="badge done">🔒 已结束</span>'
              : '<span class="badge live"><i></i>进行中</span>'}
          </div>
        </header>

        ${comp.ended
          ? '<div class="lockbar">🔒 比赛已结束，成绩已锁定。返回<a href="#/comp/' + comp.id + '">比赛页</a>可导出 Excel / PDF 赛果。</div>'
          : ''}

        <section class="card">
          <div class="board-head">
            <h3 class="card-title">⏱️ 成绩录入</h3>
            <span class="board-note">格式：秒（8.62）或 分:秒（1:01.59）· 超两位小数自动去尾 · 回车跳下一格</span>
          </div>
          <form id="entry-form" novalidate>
            <div class="entry-grid ${N === 3 ? 'cols-3' : ''}">
              <div class="field f-name">
                <label for="p-name">选手姓名</label>
                <div class="name-wrap">
                  <input id="p-name" placeholder="输入姓名可下拉选择已录选手" autocomplete="off"
                    ${comp.ended ? 'disabled' : ''}>
                  <div class="ac-list" id="ac-list" role="listbox" aria-label="选手候选"></div>
                </div>
              </div>
              ${Array.from({ length: N }, (_, i) => `
              <div class="field f-time">
                <label for="t${i}">第 ${i + 1} 次</label>
                <input id="t${i}" class="time-input mono" inputmode="decimal"
                  autocomplete="off" ${comp.ended ? 'disabled' : ''}>
                <div class="pen-btns">
                  <button type="button" class="pen-btn pb-p2" data-pen="+2"
                    title="第 ${i + 1} 次 +2 惩罚" ${comp.ended ? 'disabled' : ''}>+2</button>
                  <button type="button" class="pen-btn pb-dnf" data-pen="dnf"
                    title="第 ${i + 1} 次 DNF（未完成）" ${comp.ended ? 'disabled' : ''}>DNF</button>
                </div>
              </div>`).join('')}
            </div>
            <div class="form-error" id="entry-error"></div>
            <div class="entry-actions" id="entry-actions"></div>
          </form>
        </section>

        <section class="card board-card">
          <div class="board-head">
            <h3 class="card-title">🏆 实时排行榜</h3>
            <span class="board-note">${boardNote}</span>
          </div>
          <div class="table-wrap" id="table-wrap">
            <table class="board">
              <thead>
                <tr>
                  <th class="c-rank">排名</th>
                  <th class="c-name">选手</th>
                  <th class="c-num">最好</th>
                  <th class="c-num">${AVG}</th>
                  <th class="c-detail">${N} 次详情</th>
                  <th class="c-ops"></th>
                </tr>
              </thead>
              <tbody id="board-body"></tbody>
            </table>
          </div>
          <div class="empty" id="board-empty" style="display:none">
            暂无成绩，录入上方选手的成绩即可开启排行 🚀
          </div>
        </section>
      </main>`;

    /* ---------- 排行榜渲染（含 FLIP 动效） ---------- */
    const tbody = document.getElementById('board-body');
    const emptyBox = document.getElementById('board-empty');
    const tableWrap = document.getElementById('table-wrap');

    function movementBadge(name, rank) {
      if (!lastRanks) return '';
      const old = lastRanks.get(name);
      if (old === undefined) return '<span class="mv mv-new">新</span>';
      const d = old - rank;
      if (d > 0) return `<span class="mv up">▲${d}</span>`;
      if (d < 0) return `<span class="mv down">▼${-d}</span>`;
      return '';
    }

    function boardRow(r) {
      const chips = r.times.map((t, i) => {
        const cls = ['t-chip', 'mono'];
        if (t.pen === 'dnf') cls.push('t-dnf');
        if (i === r.bestIdx) cls.push('t-best');
        else if (i === r.worstIdx && r.markWorst) cls.push('t-worst');
        return `<span class="${cls.join(' ')}">${esc(fmtTime(t.val, t.pen))}</span>`;
      }).join('');
      return `
        <tr data-pk="${esc(r.name)}">
          <td class="c-rank">
            <span class="rank-badge ${r.rank <= 3 ? 'r' + r.rank : ''}">${r.rank}</span>
            ${movementBadge(r.name, r.rank)}
          </td>
          <td class="c-name">
            <button class="name-btn" data-player="${esc(r.name)}" title="查看该选手本场的各项目表现">
              ${esc(r.name)} <span class="name-arrow">↗</span>
            </button>
          </td>
          <td class="c-num mono">${esc(r.bestDisp)}</td>
          <td class="c-num mono ao5">${esc(r.ao5Disp)}</td>
          <td class="c-detail"><span class="t-chips">${chips}</span></td>
          <td class="c-ops">
            ${comp.ended ? '' : `
              <button class="icon-btn" data-edit="${esc(r.name)}" title="编辑该选手成绩">✏️</button>
              <button class="icon-btn del" data-del="${esc(r.name)}" title="删除该选手成绩">🗑</button>`}
          </td>
        </tr>`;
    }

    /**
     * 刷新排行榜
     * @param animate 是否播放 FLIP 重排动效
     * @param flashName 需要高亮闪烁的选手名
     */
    function refreshBoard(animate, flashName) {
      const rows = D.rankList(comp, evId);
      tableWrap.style.display = rows.length ? '' : 'none';
      emptyBox.style.display = rows.length ? 'none' : '';

      if (!animate) {
        tbody.innerHTML = rows.map(boardRow).join('');
      } else {
        /* FLIP：记录旧行位置 → 重渲染 → 反向位移 → 归位动画 */
        const before = new Map();
        tbody.querySelectorAll('tr[data-pk]').forEach((tr) => {
          before.set(tr.dataset.pk, tr.getBoundingClientRect().top);
        });
        tbody.innerHTML = rows.map(boardRow).join('');
        tbody.querySelectorAll('tr[data-pk]').forEach((tr) => {
          const oldTop = before.get(tr.dataset.pk);
          if (oldTop === undefined) {
            tr.classList.add('row-new');
            return;
          }
          const dy = oldTop - tr.getBoundingClientRect().top;
          if (Math.abs(dy) > 2) {
            tr.animate(
              [
                { transform: `translateY(${dy}px)` },
                { transform: 'translateY(0px)' },
              ],
              { duration: 500, easing: 'cubic-bezier(.22,.9,.32,1)' }
            );
          }
        });
      }

      if (flashName) {
        const tr = tbody.querySelector(`tr[data-pk="${cssEscape(flashName)}"]`);
        if (tr) {
          tr.classList.remove('row-flash');
          void tr.offsetWidth; /* 重启动画 */
          tr.classList.add('row-flash');
        }
      }
      lastRanks = new Map(rows.map((r) => [r.name, r.rank]));
    }

    /* 行内事件（委托，一次绑定） */
    tbody.addEventListener('click', (e) => {
      const delBtn = e.target.closest('[data-del]');
      if (delBtn) {
        const nm = delBtn.dataset.del;
        confirmDialog({
          title: '删除成绩',
          text: `将删除 <b>${esc(nm)}</b> 在「${esc(ev.name)}」项目的全部成绩。`,
          okText: '删除',
          danger: true,
        }).then((ok) => {
          if (!ok) return;
          D.deleteRecord(comp, evId, nm);
          rebuildACSource();
          toast(`已删除 ${nm} 的成绩`);
          if (editingName === nm) resetForm();
          refreshBoard(true);
        });
        return;
      }
      const editBtn = e.target.closest('[data-edit]');
      if (editBtn) { startEdit(editBtn.dataset.edit); return; }
      const nameBtn = e.target.closest('[data-player]');
      if (nameBtn) { openPlayerModal(comp, nameBtn.dataset.player, evId); }
    });

    /* ---------- 录入表单 ---------- */
    const form = document.getElementById('entry-form');
    const pName = document.getElementById('p-name');
    const acList = document.getElementById('ac-list');
    const tEls = Array.from({ length: N }, (_, i) => document.getElementById('t' + i));
    const penEls = [...form.querySelectorAll('.pen-btns')];
    const errBox = document.getElementById('entry-error');
    const actionsEl = document.getElementById('entry-actions');

    /* 惩罚按钮状态读写 */
    const penOf = (i) => {
      const on = penEls[i].querySelector('.pen-btn.on');
      return on ? on.dataset.pen : '';
    };
    const setPen = (i, pen) => {
      penEls[i].querySelectorAll('.pen-btn').forEach((b) => {
        b.classList.toggle('on', b.dataset.pen === pen);
      });
    };

    /* 惩罚按钮点击：选中互斥，再点取消 */
    form.addEventListener('click', (e) => {
      const b = e.target.closest('.pen-btn');
      if (!b) return;
      const box = b.closest('.pen-btns');
      const was = b.classList.contains('on');
      box.querySelectorAll('.pen-btn').forEach((x) => x.classList.remove('on'));
      if (!was) b.classList.add('on');
    });

    function submitForm() {
      if (form.requestSubmit) form.requestSubmit();
      else {
        const btn = form.querySelector('[type="submit"]');
        if (btn) btn.click();
      }
    }

    /* ---------- 姓名输入：选手库关联下拉 + 精确匹配带出 ---------- */

    /* 全局选手库（含本项目历史最好），提交/删除后重算 */
    let acSource = [];
    function rebuildACSource() {
      acSource = D.allPlayerStats().map((p) => ({
        name: p.name,
        bestDisp: (p.events[evId] || {}).bestDisp || null,
      }));
      acSource.sort((a, b) => a.name.localeCompare(b.name, 'zh'));
    }
    rebuildACSource();

    let acOpen = false;
    let acIdx = -1;   /* 键盘高亮项下标 */

    function acCandidates() {
      const v = pName.value.trim().toLowerCase();
      if (!v) return acSource.slice(0, 8);
      const eq = [], pre = [], inc = [];
      acSource.forEach((p) => {
        const nm = p.name.toLowerCase();
        if (nm === v) eq.push(p);
        else if (nm.startsWith(v)) pre.push(p);
        else if (nm.includes(v)) inc.push(p);
      });
      return [...eq, ...pre, ...inc].slice(0, 8);
    }

    function renderAC() {
      const list = acCandidates();
      if (!list.length) { closeAC(); return; }
      acList.innerHTML = list.map((p, i) => `
        <div class="ac-item ${i === acIdx ? 'on' : ''}" data-ac="${esc(p.name)}" role="option"
          title="${esc(p.name)}">
          <span class="ac-name">${esc(p.name)}</span>
          <span class="ac-best mono">${p.bestDisp ? `本项目最好 ${esc(p.bestDisp)}` : '新选手'}</span>
        </div>`).join('');
      acList.classList.add('open');
      acOpen = true;
    }

    function closeAC() {
      acList.classList.remove('open');
      acList.innerHTML = '';
      acOpen = false;
      acIdx = -1;
    }

    /* 候选项高亮（键盘 ↑↓ 时用） */
    function moveAC(step) {
      const items = acList.querySelectorAll('.ac-item');
      if (!items.length) return;
      acIdx = (acIdx + step + items.length) % items.length;
      items.forEach((el, i) => el.classList.toggle('on', i === acIdx));
      items[acIdx].scrollIntoView({ block: 'nearest' });
    }

    function pickAC(name) {
      pName.value = name;
      closeAC();
      autoLink();
      pName.classList.remove('invalid');
      if (!pName.disabled) tEls[0].focus();
    }

    /* 候选点击：mousedown 阻止输入框先失焦，click 选中 */
    acList.addEventListener('mousedown', (e) => {
      if (e.target.closest('.ac-item')) e.preventDefault();
    });
    acList.addEventListener('click', (e) => {
      const item = e.target.closest('.ac-item');
      if (item) pickAC(item.dataset.ac);
    });

    /* 姓名键盘：↑↓ 高亮 / Enter 选中 / Esc 关闭；其余按键冒泡给回车跳格逻辑 */
    pName.addEventListener('keydown', (e) => {
      if (!acOpen) {
        if (e.key === 'ArrowDown') { renderAC(); e.preventDefault(); }
        return;
      }
      if (e.key === 'ArrowDown') { moveAC(1); e.preventDefault(); e.stopPropagation(); }
      else if (e.key === 'ArrowUp') { moveAC(-1); e.preventDefault(); e.stopPropagation(); }
      else if (e.key === 'Enter') {
        if (acIdx >= 0) {
          const item = acList.querySelectorAll('.ac-item')[acIdx];
          if (item) { pickAC(item.dataset.ac); e.preventDefault(); e.stopPropagation(); }
        } else closeAC();
      } else if (e.key === 'Escape') { closeAC(); e.stopPropagation(); }
    });

    pName.addEventListener('input', () => {
      pName.classList.remove('invalid');
      acIdx = -1;
      renderAC();
      autoLink();
    });
    pName.addEventListener('focus', () => { acIdx = -1; renderAC(); });
    pName.addEventListener('blur', closeAC);

    /**
     * 精确匹配带出：输入姓名与本项目已有记录全等时，
     * 自动带出旧成绩进入“编辑已有”态（成绩格全空或本就处于该编辑态时才覆盖，避免丢输入）；
     * 名字改开则退出编辑态，已填成绩保留为底稿（提交即新建该选手记录）。
     */
    function autoLink() {
      if (comp.ended) return;
      const v = pName.value.trim();
      if (!v) {
        if (editingName && !pName.disabled) {
          editingName = null;
          setFormMode();
        }
        return;
      }
      if (pName.disabled) return; /* 排行榜 ✏️ 进入的锁定编辑态 */
      const rec = (comp.results[evId] || []).find((r) => r.name === v);
      const canFill = tEls.every((el) => !String(el.value).trim());
      if (rec && (canFill || editingName === v)) {
        editingName = v;
        fillTimes(rec);
        errBox.textContent = '';
        setFormMode();
      } else if (editingName && v !== editingName) {
        editingName = null;
        setFormMode();
      }
    }

    function fillTimes(rec) {
      (rec.times || []).slice(0, N).forEach((t, i) => {
        tEls[i].value = t.raw || '';
        tEls[i].classList.remove('invalid');
        setPen(i, t.pen || '');
      });
    }

    /* 回车跳格：姓名 → 第1次 → … → 第N次 → 提交；惩罚按钮上回车 = 切换并跳格 */
    form.addEventListener('keydown', (e) => {
      if (e.key !== 'Enter') return;
      if (comp.ended) return;
      e.preventDefault();
      const penBtn = e.target.closest('.pen-btn');
      if (penBtn) {
        penBtn.click();
        const pi = penEls.indexOf(penBtn.closest('.pen-btns'));
        if (pi < N - 1) tEls[pi + 1].focus();
        else submitForm();
        return;
      }
      const chain = [pName, ...tEls];
      const idx = chain.indexOf(e.target);
      if (idx >= 0) {
        if (idx < chain.length - 1) chain[idx + 1].focus();
        else submitForm();
      }
    });

    function setFormMode() {
      if (editingName) {
        actionsEl.innerHTML = `
          <span class="edit-hint">正在编辑 <b>${esc(editingName)}</b> 的成绩</span>
          <span class="flex-grow"></span>
          <button class="btn ghost" type="button" id="cancel-edit">取消</button>
          <button class="btn danger-ghost" type="button" id="del-record">🗑 删除成绩</button>
          <button class="btn primary" type="submit" ${comp.ended ? 'disabled' : ''}>💾 保存修改</button>`;
        document.getElementById('cancel-edit').addEventListener('click', resetForm);
        document.getElementById('del-record').addEventListener('click', async () => {
          const ok = await confirmDialog({
            title: '删除成绩',
            text: `将删除 <b>${esc(editingName)}</b> 在「${esc(ev.name)}」项目的全部成绩。`,
            okText: '删除',
            danger: true,
          });
          if (!ok) return;
          D.deleteRecord(comp, evId, editingName);
          rebuildACSource();
          toast(`已删除 ${editingName} 的成绩`);
          resetForm();
          refreshBoard(true);
        });
      } else {
        actionsEl.innerHTML = `
          <button class="btn primary" type="submit" ${comp.ended ? 'disabled' : ''}>✅ 确认成绩</button>`;
      }
    }

    function resetForm() {
      editingName = null;
      pName.disabled = comp.ended;
      pName.value = '';
      tEls.forEach((el) => { el.value = ''; el.classList.remove('invalid'); });
      penEls.forEach((_, i) => setPen(i, ''));
      errBox.textContent = '';
      closeAC();
      setFormMode();
      if (!comp.ended) pName.focus();
    }

    function startEdit(name) {
      if (comp.ended) return;
      const rec = (comp.results[evId] || []).find((r) => r.name === name);
      if (!rec) return;
      editingName = name;
      pName.value = name;
      pName.disabled = true; /* 编辑时锁定姓名 */
      fillTimes(rec);
      errBox.textContent = '';
      closeAC();
      setFormMode();
      form.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      tEls[0].focus();
    }

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      if (comp.ended) return;
      errBox.textContent = '';
      tEls.forEach((el) => el.classList.remove('invalid'));
      pName.classList.remove('invalid');

      const name = pName.value.trim();
      const raws = tEls.map((el) => el.value);
      const pens = tEls.map((_, i) => penOf(i));
      const errs = [];

      if (!name) { errs.push('请填写选手姓名'); pName.classList.add('invalid'); }
      else if (name.length > 24) { errs.push('选手姓名过长（≤ 24 字符）'); pName.classList.add('invalid'); }
      else {
        const dup = (comp.results[evId] || []).find(
          (r) => r.name === name && r.name !== editingName
        );
        if (dup) {
          errs.push(`选手「${name}」在本项目已有成绩，可点击排行榜行尾 ✏️ 修改`);
          pName.classList.add('invalid');
        }
      }

      /* 逐次校验：DNF 允许留空（时间忽略），其余必填且格式合法 */
      const parsed = [];
      let missing = false;
      raws.forEach((r, i) => {
        const p = D.parseTime(r);
        if (pens[i] === 'dnf') {
          if (String(r).trim() && !p.ok) {
            errs.push(`第 ${i + 1} 次成绩无效：${p.reason}`);
            tEls[i].classList.add('invalid');
          }
          parsed.push({ ok: true, raw: String(r).trim(), val: p.ok ? p.val : 0, pen: 'dnf' });
        } else {
          if (!String(r).trim()) {
            if (!missing) { errs.push(`${N} 次成绩需全部填写（DNF 次数可留空）`); missing = true; }
            tEls[i].classList.add('invalid');
            parsed.push({ ok: false, raw: '', val: 0, pen: pens[i] });
          } else if (!p.ok) {
            errs.push(`第 ${i + 1} 次成绩无效：${p.reason}`);
            tEls[i].classList.add('invalid');
            parsed.push({ ok: false, raw: '', val: 0, pen: pens[i] });
          } else {
            parsed.push({ ...p, pen: pens[i] });
          }
        }
      });

      if (errs.length) {
        errBox.innerHTML = errs.map((s) => '• ' + esc(s)).join('<br>');
        return;
      }

      D.upsertRecord(comp, evId, name, parsed);
      rebuildACSource();
      toast(editingName
        ? `已更新 ${name} 的成绩，排行榜已刷新`
        : `已录入 ${name} 的成绩，排行榜已更新 🏆`);
      resetForm();
      refreshBoard(true, name);
    });

    /* 输入时即时清除错误样式 */
    [pName, ...tEls].forEach((el) => {
      el.addEventListener('input', () => el.classList.remove('invalid'));
    });

    /* ---------- 选手详情弹窗（项目 Tab + 折线图 + 扩展统计） ---------- */

    /* 成绩折线图（SVG，DNF 断线 + 顶部 ✕ 标记） */
    function lineChartSVG(info) {
      const W = 520, H = 200, PL = 48, PR = 14, PT = 30, PB = 30;
      const effs = info.effs;
      const finite = effs.filter((v) => isFinite(v));
      if (!finite.length) return '<div class="chart-empty">全部 DNF，暂无可绘制的成绩</div>';
      let min0 = Math.min(...finite);
      let max0 = Math.max(...finite);
      if (max0 - min0 < 1e-9) {
        max0 = min0 + Math.max(1, min0 * 0.1);
        min0 = Math.max(0, min0 - Math.max(1, min0 * 0.1));
      }
      const span = max0 - min0;
      const lo = min0 - span * 0.12;
      const hi = max0 + span * 0.12;
      const X = (i) => PL + (i * (W - PL - PR)) / (effs.length - 1 || 1);
      const Y = (v) => PT + ((hi - v) / (hi - lo)) * (H - PT - PB);

      /* 连续有效段（DNF 断开） */
      const segs = [];
      let cur = [];
      effs.forEach((v, i) => {
        if (isFinite(v)) cur.push(i);
        else if (cur.length) { segs.push(cur); cur = []; }
      });
      if (cur.length) segs.push(cur);

      const lines = segs.filter((s) => s.length > 1).map((s) =>
        `<polyline points="${s.map((i) => `${X(i).toFixed(1)},${Y(effs[i]).toFixed(1)}`).join(' ')}" class="chart-line"/>`
      ).join('');

      const dots = effs.map((v, i) => {
        if (!isFinite(v)) return '';
        let cls = 'chart-dot';
        if (i === info.bestIdx) cls += ' best';
        else if (i === info.worstIdx && info.dnfCount === 0) cls += ' worst';
        return `<circle cx="${X(i).toFixed(1)}" cy="${Y(v).toFixed(1)}" r="4.5" class="${cls}"/>`;
      }).join('');

      const vals = info.times.map((t, i) => {
        if (!isFinite(effs[i])) return '';
        return `<text x="${X(i).toFixed(1)}" y="${(Y(effs[i]) - 11).toFixed(1)}" class="chart-val" text-anchor="middle">${esc(fmtTime(t.val, t.pen))}</text>`;
      }).join('');

      const dnfMarks = effs.map((v, i) => {
        if (isFinite(v)) return '';
        return `<text x="${X(i).toFixed(1)}" y="17" class="chart-dnf" text-anchor="middle">✕</text>`;
      }).join('');

      const xAx = effs.map((v, i) =>
        `<text x="${X(i).toFixed(1)}" y="${H - 9}" class="chart-ax" text-anchor="middle">第${i + 1}次</text>`).join('');
      const yAx = `
        <text x="6" y="${Y(max0).toFixed(1)}" class="chart-ax" dominant-baseline="middle">${esc(fmtTime(max0, ''))}</text>
        <text x="6" y="${Y(min0).toFixed(1)}" class="chart-ax" dominant-baseline="middle">${esc(fmtTime(min0, ''))}</text>
        <line x1="${PL - 8}" y1="${Y(max0).toFixed(1)}" x2="${W - PR}" y2="${Y(max0).toFixed(1)}" class="chart-axis"/>
        <line x1="${PL - 8}" y1="${Y(min0).toFixed(1)}" x2="${W - PR}" y2="${Y(min0).toFixed(1)}" class="chart-axis"/>`;

      return `<svg class="line-chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="${effs.length} 次成绩折线图">
        ${yAx}${lines}${dots}${vals}${dnfMarks}${xAx}
      </svg>`;
    }

    /* 弹窗内容：某个项目一个面板 */
    function playerPane(c, name, eid) {
      const e2 = D.eventById(eid);
      const rows = D.rankList(c, eid);
      const info = rows.find((r) => r.name === name);
      if (!info) {
        return `<div class="pe-none-box">未参加 <b>${esc(e2.name)}</b> 项目</div>`;
      }
      const fmtOr = (v, isTime) => {
        if (v == null) return '—';
        if (!isFinite(v)) return 'DNF';
        return isTime ? fmtTime(v, '') : fmt2(v);
      };
      const ciDisp = info.ci
        ? `${fmtTime(info.ci.lo, '')} ~ ${fmtTime(info.ci.hi, '')}（n=${info.ci.n}）`
        : '—';
      return `
        <div class="pe-stats">
          <div class="pe-stat"><span>名次</span><b>第 ${info.rank} / ${rows.length} 名</b></div>
          <div class="pe-stat"><span>最好</span><b class="mono">${esc(info.bestDisp)}</b></div>
          <div class="pe-stat"><span>${e2.attempts === 3 ? 'Ao3' : 'Ao5'}</span><b class="mono">${esc(info.ao5Disp)}</b></div>
        </div>
        <div class="chart-box">${lineChartSVG(info)}</div>
        <div class="pe-stats ext">
          <div class="pe-stat"><span>均值</span><b class="mono">${fmtOr(info.mean, true)}</b></div>
          <div class="pe-stat"><span>标准差</span><b class="mono">${fmtOr(info.sd, false)}</b></div>
          <div class="pe-stat"><span>极差</span><b class="mono">${fmtOr(info.range, true)}</b></div>
          <div class="pe-stat"><span>95% 置信区间</span><b class="mono">${ciDisp}</b></div>
        </div>
        <p class="bar-legend">
          <span class="lg-dot best"></span>最好
          <span class="lg-dot worst"></span>最坏
          <span class="dnf-x">✕</span>DNF（断线）
          标准差为样本标准差（n−1）· 置信区间 = 均值 ± t·s/√n（95%，t 分布）
        </p>`;
    }

    function openPlayerModal(c, name, selEvId) {
      const evIds = c.events;
      if (!evIds.includes(selEvId)) selEvId = evIds[0];
      const tabsHtml = evIds.map((id) => {
        const e3 = D.eventById(id);
        return `<button class="m-tab ${id === selEvId ? 'on' : ''}" data-tab="${id}"
          style="--c:${e3.color}">${e3.icon} ${esc(e3.name)}</button>`;
      }).join('');

      $modalRoot.innerHTML = `
        <div class="modal-overlay">
          <div class="modal player-modal">
            <header class="m-head">
              <h3>👤 ${esc(name)} <span class="m-head-sub">· ${esc(c.name)}</span></h3>
              <div class="m-head-right">
                <a class="linklike" href="#/player/${encodeURIComponent(name)}" data-close>选手主页 →</a>
                <button class="icon-btn" data-close title="关闭">✕</button>
              </div>
            </header>
            <div class="m-tabs">${tabsHtml}</div>
            <div class="m-body">${playerPane(c, name, selEvId)}</div>
          </div>
        </div>`;

      const overlay = $modalRoot.firstElementChild;
      const onKey = (e) => { if (e.key === 'Escape') close(); };
      function close() {
        overlay.classList.add('closing');
        setTimeout(() => { $modalRoot.innerHTML = ''; }, 170);
        document.removeEventListener('keydown', onKey);
      }
      document.addEventListener('keydown', onKey);
      overlay.addEventListener('click', (e) => { if (e.target === overlay) close(); });
      overlay.querySelectorAll('[data-close]').forEach((b) => b.addEventListener('click', close));
      overlay.querySelectorAll('[data-tab]').forEach((t) => {
        t.addEventListener('click', () => {
          overlay.querySelectorAll('[data-tab]').forEach((x) => x.classList.toggle('on', x === t));
          overlay.querySelector('.m-body').innerHTML = playerPane(c, name, t.dataset.tab);
        });
      });
    }

    /* ---------- 初始化 ---------- */
    setFormMode();
    refreshBoard(false);
    if (!comp.ended) pName.focus();
  }

  /* ================= 选手库（跨比赛聚合列表） ================= */
  let playersView = { ev: '3x3', mode: 'best', q: '' };

  function renderPlayers() {
    if (!D.EVENTS.some((e) => e.id === playersView.ev)) {
      playersView.ev = D.EVENTS[0].id;
    }

    $app.innerHTML = `
      <main class="container">
        <nav class="crumbs">
          <a href="#/">首页</a><span>/</span><b>选手</b>
        </nav>
        <header class="page-head">
          <div class="head-info">
            <h2>👤 选手</h2>
            <p class="sub">跨全部比赛的历史成绩汇总 · 点击选手名进入主页</p>
          </div>
        </header>

        <section class="card">
          <div class="pl-controls">
            <div class="m-tabs">
              ${D.EVENTS.map((ev) => `
                <button class="m-tab ${ev.id === playersView.ev ? 'on' : ''}" data-tab="${ev.id}"
                  style="--c:${ev.color}">${ev.icon} ${esc(ev.name)}</button>`).join('')}
            </div>
            <div class="mode-toggle" title="排序指标">
              <button class="mode-btn ${playersView.mode === 'best' ? 'on' : ''}" data-mode="best">单次</button>
              <button class="mode-btn ${playersView.mode === 'ao5' ? 'on' : ''}" data-mode="ao5">平均</button>
            </div>
            <input id="pl-search" class="pl-search" placeholder="🔍 搜索选手…" value="${esc(playersView.q)}">
          </div>

          <div class="table-wrap" id="pl-wrap">
            <table class="board pl-table">
              <thead>
                <tr>
                  <th class="c-rank">排名</th>
                  <th class="c-name">选手</th>
                  <th class="c-num">单次</th>
                  <th class="c-num">${(D.eventById(playersView.ev) || {}).attempts === 3 ? 'Ao3' : 'Ao5'}</th>
                  <th class="c-medal">🥇</th>
                  <th class="c-medal">🥈</th>
                  <th class="c-medal">🥉</th>
                  <th class="c-num">还原/尝试</th>
                  <th class="c-num">轮次</th>
                </tr>
              </thead>
              <tbody id="pl-body"></tbody>
            </table>
          </div>
          <div class="empty" id="pl-empty" style="display:none">没有匹配的选手</div>
          <p class="board-note" style="margin-top:10px">
            按${playersView.mode === 'best' ? '历史最好单次' : '历史最好平均'}排序（竞赛制并列）· 奖牌 / 还原按当前项目统计
          </p>
        </section>
      </main>`;

    const tbody = document.getElementById('pl-body');
    const emptyBox = document.getElementById('pl-empty');
    const wrap = document.getElementById('pl-wrap');

    function renderBody() {
      const evId = playersView.ev;
      const mode = playersView.mode;
      const ranking = D.playerRanking(evId, mode);
      const stats = new Map(D.allPlayerStats().map((p) => [p.name, p]));
      const q = playersView.q.trim().toLowerCase();

      const rows = ranking.filter((r) => !q || r.name.toLowerCase().includes(q));
      wrap.style.display = rows.length ? '' : 'none';
      emptyBox.style.display = rows.length ? 'none' : '';

      tbody.innerHTML = rows.map((r) => {
        const p = stats.get(r.name);
        const e = p && p.events[evId];
        if (!e) return '';
        const medal = (n) => (n > 0 ? `<b class="md">${n}</b>` : '<span class="md-zero">·</span>');
        return `
          <tr>
            <td class="c-rank"><span class="rank-badge ${r.rank <= 3 ? 'r' + r.rank : ''}">${r.rank}</span></td>
            <td class="c-name">
              <a class="pl-name" href="#/player/${encodeURIComponent(r.name)}">${esc(r.name)} <span class="name-arrow">↗</span></a>
            </td>
            <td class="c-num mono">${esc(e.bestDisp)}</td>
            <td class="c-num mono ao5">${esc(e.ao5Disp)}</td>
            <td class="c-medal">${medal(e.medals.g)}</td>
            <td class="c-medal">${medal(e.medals.s)}</td>
            <td class="c-medal">${medal(e.medals.b)}</td>
            <td class="c-num mono">${e.solved}/${e.attempts}</td>
            <td class="c-num mono">${e.rounds}</td>
          </tr>`;
      }).join('');
    }

    renderBody();

    /* 搜索：只重绘表格体，保持输入焦点 */
    document.getElementById('pl-search').addEventListener('input', (e) => {
      playersView.q = e.target.value;
      renderBody();
    });

    /* 项目 / 指标切换：整页重绘（状态保留） */
    $app.querySelectorAll('[data-tab]').forEach((t) => {
      t.addEventListener('click', () => {
        playersView.ev = t.dataset.tab;
        renderPlayers();
      });
    });
    $app.querySelectorAll('[data-mode]').forEach((b) => {
      b.addEventListener('click', () => {
        if (playersView.mode === b.dataset.mode) return;
        playersView.mode = b.dataset.mode;
        renderPlayers();
      });
    });
  }

  /* ================= 纪录（俱乐部纪录榜） ================= */
  function renderRecords() {
    const records = D.clubRecords();
    const holders = new Set();
    records.forEach((r) => {
      if (r.single) holders.add(r.single.name);
      if (r.avg) holders.add(r.avg.name);
    });
    const nEv = records.filter((r) => r.single || r.avg).length;

    const holderCell = (r) => (r
      ? `<a class="pl-name" href="#/player/${encodeURIComponent(r.name)}">${esc(r.name)} <span class="name-arrow">↗</span></a>`
      : '<span class="dim">—</span>');
    const compCell = (r) => (r
      ? `<a class="pl-name" href="#/comp/${r.compId}">${esc(r.compName)}</a>`
      : '<span class="dim">—</span>');
    const dateCell = (r) => (r ? `<span class="mono dim">${dotted(r.date)}</span>` : '<span class="dim">—</span>');
    const detailCell = (r) => (r
      ? `<span class="t-chips">${(r.times || []).map((t) =>
        `<span class="t-chip mono${t.pen === 'dnf' ? ' t-dnf' : ''}">${esc(fmtTime(t.val, t.pen))}</span>`).join('')}</span>`
      : '');

    const rowsHtml = records.map((rec) => {
      const ev = D.eventById(rec.evId);
      const group = `
        <tr class="rec-group">
          <td colspan="7"><span class="chip" style="--c:${ev.color}">${ev.icon} ${esc(ev.name)}</span>
            <span class="rec-avg-tag">${ev.attempts === 3 ? '三次制' : '五次制'}</span></td>
        </tr>`;
      if (!rec.single && !rec.avg) {
        return group + `
        <tr class="rec-empty"><td colspan="7">该项目暂无有效纪录</td></tr>`;
      }
      const line = (kind, r) => `
        <tr>
          <td class="c-rec"><span class="cr-kind">${kind}纪录</span></td>
          <td class="c-num mono">${kind === '单次' ? (r ? esc(r.disp) : '–') : '<span class="dim">—</span>'}</td>
          <td class="c-num mono ao5">${kind === '平均' ? (r ? esc(r.disp) : '–') : '<span class="dim">—</span>'}</td>
          <td class="c-name">${holderCell(r)}</td>
          <td class="c-comp">${compCell(r)}</td>
          <td class="c-date">${dateCell(r)}</td>
          <td class="c-detail">${detailCell(r)}</td>
        </tr>`;
      return group
        + (rec.single ? line('单次', rec.single) : '')
        + (rec.avg ? line('平均', rec.avg) : '');
    }).join('');

    $app.innerHTML = `
      <main class="container">
        <nav class="crumbs">
          <a href="#/">首页</a><span>/</span><b>纪录</b>
        </nav>
        <header class="page-head">
          <div class="head-info">
            <h2>📜 纪录</h2>
            <p class="sub">各项目历史最佳单次 / 平均 · 点击姓名进入选手主页，点击赛事进入比赛</p>
          </div>
        </header>

        <section class="card">
          <div class="table-wrap">
            <table class="board rec-table">
              <thead>
                <tr>
                  <th class="c-rec">纪录</th>
                  <th class="c-num">单次</th>
                  <th class="c-num">平均</th>
                  <th class="c-name">姓名</th>
                  <th class="c-comp">赛事</th>
                  <th class="c-date">日期</th>
                  <th class="c-detail">详情（一轮内全部成绩）</th>
                </tr>
              </thead>
              <tbody>${rowsHtml}</tbody>
            </table>
          </div>
          <p class="board-note" style="margin-top:10px">
            ${nEv} 个项目有纪录 · ${holders.size} 位纪录保持者 · 单次与平均纪录分别独立评选 · 平均 = ${'三次制项目为三次直接平均，五次制为去头去尾'}
          </p>
        </section>
      </main>`;
  }

  /* ================= PK 对战 ================= */
  const PK_SKIP_KEY = 'sjtu-cube-weekly-pk-skip';
  let pkView = {
    left: '',
    right: '',
    skip: localStorage.getItem(PK_SKIP_KEY) !== '0',
  };

  function renderPK(left, right) {
    if (left) pkView.left = left;
    if (right) pkView.right = right;
    const all = D.allPlayerStats();
    const names = all.map((p) => p.name).sort((a, b) => a.localeCompare(b, 'zh'));

    const options = (sel) => `<option value="">— 选择选手 —</option>`
      + names.map((n) => `<option value="${esc(n)}" ${n === sel ? 'selected' : ''}>${esc(n)}</option>`).join('');

    const A = all.find((p) => p.name === pkView.left);
    const B = all.find((p) => p.name === pkView.right);
    const ready = !!(A && B && A.name !== B.name);

    /* 对局计算：每个项目两个 PK 点（单次 / 平均），成绩更佳者得 1 分 */
    const rows = [];
    const total = { lb: 0, rb: 0, la: 0, ra: 0 };
    if (ready) {
      D.EVENTS.forEach((ev) => {
        const ea = A.events[ev.id];
        const eb = B.events[ev.id];
        if (!ea && !eb) return;                       /* 双方都未参加：不渲染不计分 */
        if (pkView.skip && (!ea || !eb)) return;      /* 未参加项目除外 */
        const cmp = (x, y) => {
          if (!isFinite(x) && !isFinite(y)) return 0;
          if (x < y - 1e-9) return 1;
          if (x > y + 1e-9) return -1;
          return 0;
        };
        const sb = cmp(ea ? ea.best : Infinity, eb ? eb.best : Infinity);
        const sg = cmp(ea ? ea.ao5 : Infinity, eb ? eb.ao5 : Infinity);
        if (sb > 0) total.lb++; else if (sb < 0) total.rb++;
        if (sg > 0) total.la++; else if (sg < 0) total.ra++;
        rows.push({ ev, ea, eb, sb, sg });
      });
    }
    const lTotal = total.lb + total.la;
    const rTotal = total.rb + total.ra;
    const lPct = (lTotal + rTotal) ? Math.round((lTotal / (lTotal + rTotal)) * 100) : 50;

    const valCell = (e, win) => {
      if (!e) return '<span class="pk-val dim">未参加</span>';
      const txt = esc(e);
      if (win === 1) return `<span class="pk-val mono pk-win">✦ ${txt}</span>`;
      if (win === -1) return `<span class="pk-val mono dim">${txt}</span>`;
      return `<span class="pk-val mono">${txt}</span>`;
    };
    const rowsHtml = rows.map((r) => {
      const sl = (r.sb > 0 ? 1 : 0) + (r.sg > 0 ? 1 : 0);
      const sr = (r.sb < 0 ? 1 : 0) + (r.sg < 0 ? 1 : 0);
      return `
        <tr>
          <td>
            <span class="chip" style="--c:${r.ev.color}">${r.ev.icon} ${esc(r.ev.name)}</span>
            <span class="pk-row-score ${sl > sr ? 'l' : sr > sl ? 'r' : ''}">${sl}:${sr}</span>
          </td>
          <td class="c-num">${valCell(r.ea && r.ea.bestDisp, r.sb)}</td>
          <td class="c-num">${valCell(r.ea && r.ea.ao5Disp, r.sg)}</td>
          <td class="c-num">${valCell(r.eb && r.eb.bestDisp, -r.sb)}</td>
          <td class="c-num">${valCell(r.eb && r.eb.ao5Disp, -r.sg)}</td>
        </tr>`;
    }).join('');

    const namesSafe = (n) => esc(n || '—');
    $app.innerHTML = `
      <main class="container">
        <nav class="crumbs">
          <a href="#/">首页</a><span>/</span><b>PK</b>
        </nav>
        <header class="page-head">
          <div class="head-info">
            <h2>⚔️ 选手 PK</h2>
            <p class="sub">逐项目比历史最佳单次 / 平均，更佳者得 1 分 · 共 ${D.EVENTS.length} 项目 × 2 分</p>
          </div>
        </header>

        <section class="card pk-head">
          <div class="pk-side pk-left">
            <label class="pk-label">左方选手</label>
            <select id="pk-a" class="pk-select">${options(pkView.left)}</select>
            <span class="pk-name">${namesSafe(A && A.name)}</span>
          </div>
          <div class="pk-mid">
            <button class="icon-btn pk-swap" id="pk-swap" title="交换左右选手">⇄</button>
            ${ready ? `
            <div class="pk-score mono"><b class="${lTotal > rTotal ? 'win' : ''}">${lTotal}</b>
              <span class="pk-vs">:</span>
              <b class="${rTotal > lTotal ? 'win' : ''}">${rTotal}</b></div>
            <div class="pk-bar" title="总比分比例">
              <div class="pk-bar-l" style="width:${lPct}%"></div>
            </div>
            <div class="pk-sub mono">单次 ${total.lb}:${total.rb} · 平均 ${total.la}:${total.ra}</div>
            ${lTotal !== rTotal ? `<div class="pk-champ">🏆 ${esc(lTotal > rTotal ? A.name : B.name)} 获胜</div>`
              : (lTotal + rTotal ? '<div class="pk-champ tie">势均力敌</div>' : '')}`
            : '<div class="pk-vs-idle">VS</div>'}
          </div>
          <div class="pk-side pk-right">
            <label class="pk-label">右方选手</label>
            <select id="pk-b" class="pk-select">${options(pkView.right)}</select>
            <span class="pk-name">${namesSafe(B && B.name)}</span>
          </div>
        </section>

        <section class="card">
          <div class="pk-controls">
            <label class="pk-rule">
              <input type="checkbox" id="pk-skip" ${pkView.skip ? 'checked' : ''}>
              <span>未参加项目除外（勾选：只统计双方都参加的项目；不勾：未参加按落败计）</span>
            </label>
          </div>
          ${ready ? (rows.length ? `
          <div class="table-wrap">
            <table class="board pk-table">
              <thead>
                <tr>
                  <th>项目</th>
                  <th class="c-num">${namesSafe(A && A.name)} · 单次</th>
                  <th class="c-num">${namesSafe(A && A.name)} · 平均</th>
                  <th class="c-num">${namesSafe(B && B.name)} · 单次</th>
                  <th class="c-num">${namesSafe(B && B.name)} · 平均</th>
                </tr>
              </thead>
              <tbody>${rowsHtml}</tbody>
            </table>
          </div>
          <p class="board-note" style="margin-top:10px">
            ✦ = 该 PK 点胜方 · 平均列三次制为 Ao3、五次制为 Ao5 · DNF / 未参加不产生有效成绩
          </p>`
          : '<div class="empty">勾选「未参加项目除外」后没有双方都参加的项目</div>')
          : `<div class="empty">在上方选择两位不同选手开始 PK 🥊</div>`}
        </section>
      </main>`;

    const updateHash = () => {
      const h = (pkView.left && pkView.right)
        ? `#/pk/${encodeURIComponent(pkView.left)}/${encodeURIComponent(pkView.right)}`
        : '#/pk';
      history.replaceState(null, '', h);
    };
    document.getElementById('pk-a').addEventListener('change', (e) => {
      pkView.left = e.target.value;
      updateHash();
      renderPK();
    });
    document.getElementById('pk-b').addEventListener('change', (e) => {
      pkView.right = e.target.value;
      updateHash();
      renderPK();
    });
    document.getElementById('pk-swap').addEventListener('click', () => {
      const t = pkView.left;
      pkView.left = pkView.right;
      pkView.right = t;
      updateHash();
      renderPK();
    });
    document.getElementById('pk-skip').addEventListener('change', (e) => {
      pkView.skip = e.target.checked;
      localStorage.setItem(PK_SKIP_KEY, pkView.skip ? '1' : '0');
      renderPK();
    });
  }

  function renderPlayer(name) {
    const p = D.getPlayer(name);
    if (!p) return notFound();

    /* 参赛经历按比赛分组（一场比赛两个项目合并） */
    const group = new Map();
    p.comps.forEach((c) => {
      if (!group.has(c.id)) {
        group.set(c.id, { id: c.id, name: c.name, date: c.date, evs: [] });
      }
      group.get(c.id).evs.push(c);
    });
    const comps = [...group.values()].sort((a, b) =>
      String(a.date).localeCompare(String(b.date)) || String(a.name).localeCompare(String(b.name)));

    const first = comps.length ? comps[0].date : '';
    const last = comps.length ? comps[comps.length - 1].date : '';
    const dateRange = comps.length > 1 && first !== last
      ? `${dotted(first)} ~ ${dotted(last)}`
      : (first ? dotted(first) : '');

    /* 个人最好成绩表：行 = 项目，按标准项目顺序（三阶→多盲），不依赖录入先后 */
    const evIds = D.EVENTS.map((e) => e.id).filter((id) => p.events[id]);
    const pbRows = evIds.map((evId) => {
      const ev = D.eventById(evId);
      const e = p.events[evId];
      const bestRanking = D.playerRanking(evId, 'best');
      const ao5Ranking = D.playerRanking(evId, 'ao5');
      const br = bestRanking.find((r) => r.name === name);
      const ar = ao5Ranking.find((r) => r.name === name);
      const rankTxt = (r, total) => (r ? `${r.rank} / ${total}` : '—');
      return `
        <tr class="pb-row" data-evhist="${evId}" title="点击查看该项目的跨赛事成绩走势">
          <td><span class="chip" style="--c:${ev.color}">${ev.icon} ${esc(ev.name)}</span></td>
          <td class="c-num mono">${esc(e.bestDisp)}</td>
          <td class="c-num mono">${rankTxt(br, bestRanking.length)}</td>
          <td class="c-num mono ao5">${esc(e.ao5Disp)}</td>
          <td class="c-num mono">${rankTxt(ar, ao5Ranking.length)}</td>
          <td class="c-medal">${e.medals.g || 0}</td>
          <td class="c-medal">${e.medals.s || 0}</td>
          <td class="c-medal">${e.medals.b || 0}</td>
          <td class="c-num mono">${e.solved}/${e.attempts}</td>
        </tr>`;
    }).join('');

    const compLines = comps.map((c) => {
      const chips = c.evs.map((ev) => {
        const e4 = D.eventById(ev.evId);
        const medalTxt = ev.rank === 1 ? '🥇' : ev.rank === 2 ? '🥈' : ev.rank === 3 ? '🥉' : `第${ev.rank}名`;
        return `<span class="chip sm" style="--c:${e4.color}">${e4.icon} ${esc(ev.evName)} ${medalTxt} · ${esc(ev.ao5Disp)}</span>`;
      }).join('');
      return `
        <a class="comp-line" href="#/comp/${c.id}">
          <span class="cl-date mono">${dotted(c.date)}</span>
          <span class="cl-name">${esc(c.name)}</span>
          <span class="cl-evs">${chips}</span>
          <span class="cl-go">→</span>
        </a>`;
    }).join('');

    $app.innerHTML = `
      <main class="container">
        <nav class="crumbs">
          <a href="#/">首页</a><span>/</span>
          <a href="#/players">选手</a><span>/</span><b>${esc(name)}</b>
        </nav>
        <header class="page-head">
          <div class="head-info">
            <h2>👤 ${esc(name)}</h2>
            <p class="sub">${comps.length} 场比赛${dateRange ? ' · ' + dateRange : ''} · 金 ${p.medals.g} · 银 ${p.medals.s} · 铜 ${p.medals.b}</p>
          </div>
        </header>

        <section class="card">
          <h3 class="card-title">🏅 个人最好成绩</h3>
          ${evIds.length ? `
          <div class="table-wrap">
            <table class="board pb-table">
              <thead>
                <tr>
                  <th>项目</th>
                  <th class="c-num">单次</th>
                  <th class="c-num">单次排名</th>
                  <th class="c-num">平均</th>
                  <th class="c-num">平均排名</th>
                  <th class="c-medal">🥇</th>
                  <th class="c-medal">🥈</th>
                  <th class="c-medal">🥉</th>
                  <th class="c-num">还原/尝试</th>
                </tr>
              </thead>
              <tbody>${pbRows}</tbody>
            </table>
          </div>` : '<div class="empty">暂无成绩记录</div>'}
          <p class="board-note" style="margin-top:10px">排名范围 = 历史上参加过该项目的全部选手 · 点击项目行可查看跨赛事成绩图表</p>
        </section>

        <section class="card">
          <h3 class="card-title">🗓 参赛经历</h3>
          ${comps.length ? `<div class="comp-lines">${compLines}</div>`
            : '<div class="empty">暂无参赛记录</div>'}
        </section>
      </main>`;

    /* ---------- 项目历史弹窗：跨赛事全部成绩 + 柱状图 / 折线图 ---------- */
    function openEventHistory(pName, evId) {
      const ev = D.eventById(evId);
      if (!ev) return;
      const e = p.events[evId];

      /* 收集该选手该项目在所有比赛中的成绩（按日期排序，旧 → 新） */
      const rounds = [];
      D.state().competitions.forEach((c) => {
        const rec = (c.results[evId] || []).find((r) => r.name === pName);
        if (!rec) return;
        const st = D.stats(rec, ev);
        const rk = D.rankList(c, evId).find((r) => r.name === pName);
        rounds.push({
          compId: c.id, compName: c.name, date: String(c.date),
          st, rank: rk ? rk.rank : null, times: st.times,
        });
      });
      rounds.sort((a, b) => a.date.localeCompare(b.date) || a.compName.localeCompare(b.compName));

      const flat = [];
      rounds.forEach((r, ri) => r.times.forEach((t, ti) => flat.push({ t, ri, ti })));
      const eff = (t) => (t.pen === 'dnf' ? Infinity : t.val + (t.pen === '+2' ? 2 : 0));
      const flatEff = flat.map((f) => eff(f.t));
      const solved = flat.filter((f) => f.t.pen !== 'dnf').length;
      const shortDate = (d) => d.slice(2).replace(/-/g, '.');

      const aoName = ev.attempts === 3 ? 'Ao3' : 'Ao5';

      /* 图表数据源：所有成绩（每次还原）/ 单次（各场单次最好）/ 平均（各场 Ao5/Ao3） */
      let hview = 'bar';
      let hdata = 'all';
      const DATA_KINDS = [
        { id: 'all', label: '所有成绩', pt: '一次还原' },
        { id: 'single', label: '单次', pt: '每场单次最好' },
        { id: 'avg', label: '平均', pt: `每场${aoName}平均` },
      ];
      function buildDataset(kind) {
        if (kind === 'single') return rounds.map((r, i) => ({
          v: r.st.best,
          title: `${r.compName}（${dotted(r.date)}）· 单次最好 ${isFinite(r.st.best) ? esc(fmtTime(r.st.best, '')) : 'DNF'}`,
          ri: i, ti: -1,
        }));
        if (kind === 'avg') return rounds.map((r, i) => ({
          v: r.st.ao5,
          title: `${r.compName}（${dotted(r.date)}）· ${aoName} ${esc(r.st.ao5Disp)}`,
          ri: i, ti: -1,
        }));
        return flat.map((f, i) => ({
          v: flatEff[i],
          title: `${rounds[f.ri].compName}（${dotted(rounds[f.ri].date)}）第 ${f.ti + 1} 次 · ${esc(fmtTime(f.t.val, f.t.pen))}`,
          ri: f.ri, ti: f.ti,
        }));
      }

      /* 时间分布：频数分布直方图（X 轴 = 时间段，Y 轴 = 该段成绩个数） */
      function histChartSVG() {
        const kind = DATA_KINDS.find((k) => k.id === hdata);
        const pts = buildDataset(hdata);
        const finite = pts.filter((p) => isFinite(p.v)).map((p) => p.v);
        const dnf = pts.length - finite.length;
        if (!finite.length) return '<div class="chart-empty">该数据源下全部为 DNF，暂无可绘制的成绩</div>';

        /* 分桶：nice 步长（1 / 2 / 2.5 / 5 × 10^n），目标 8~10 桶 */
        let min = Math.min(...finite);
        let max = Math.max(...finite);
        if (max - min < 1e-9) { min = Math.max(0, min - 0.5); max = max + 0.5; }
        const rawStep = (max - min) / 9;
        const pow = Math.pow(10, Math.floor(Math.log10(rawStep)));
        let step = 10 * pow;
        for (const m of [1, 2, 2.5, 5]) { if (m * pow >= rawStep) { step = m * pow; break; } }
        const lo = Math.floor(min / step + 1e-9) * step;
        const nb = Math.max(1, Math.ceil((max - lo) / step + 1e-6));

        const counts = new Array(nb).fill(0);
        finite.forEach((v) => {
          counts[Math.min(nb - 1, Math.max(0, Math.floor((v - lo) / step + 1e-9)))]++;
        });
        const maxF = Math.max(...counts);

        const W = 660, H = 230, PL = 40, PR = 10, PT = 24, PB = 30;
        const X0 = PL, X1 = W - PR;
        const slot = (X1 - X0) / nb;
        const bw = Math.min(slot * 0.72, 64);
        const YB = H - PB;
        const Y = (f) => PT + ((maxF - f) / (maxF || 1)) * (YB - PT);
        const fmtB = (v) => esc(fmtTime(v, ''));

        /* y 轴频数刻度（横虚线网格，整数频数） */
        const tickStep = maxF <= 5 ? 1 : Math.ceil(maxF / 5);
        let grid = '';
        for (let f = tickStep; f <= maxF; f += tickStep) {
          grid += `<line x1="${X0}" y1="${Y(f).toFixed(1)}" x2="${X1}" y2="${Y(f).toFixed(1)}" class="chart-grid"/>
            <text x="${X0 - 6}" y="${Y(f).toFixed(1)}" class="chart-ax" text-anchor="end" dominant-baseline="middle">${f}</text>`;
        }

        /* 非空桶画柱（空桶留白，桶间距可读） */
        const bars = counts.map((n, bi) => {
          if (!n) return '';
          const a = lo + bi * step;
          const b = a + step;
          const h = Math.max(2, YB - Y(n));
          return `<rect x="${(X0 + bi * slot + (slot - bw) / 2).toFixed(1)}" y="${(YB - h).toFixed(1)}"
            width="${bw.toFixed(1)}" height="${h.toFixed(1)}" class="hist-bar" style="--c:${ev.color}">
            <title>${fmtB(a)} – ${fmtB(b)} · ${n} 个成绩</title></rect>`;
        }).join('');

        /* x 轴：桶起点时间标签（桶多时隔标签） */
        const lstep = Math.ceil(nb / 9);
        const xAx = counts.map((_, bi) => (bi % lstep === 0
          ? `<text x="${(X0 + bi * slot).toFixed(1)}" y="${H - 10}" class="chart-ax" text-anchor="middle">${fmtB(lo + bi * step)}</text>`
          : '')).join('');

        const stepTxt = step >= 60 ? esc(fmtTime(step, '')) : `${+(step.toFixed(2))} 秒`;
        return `<svg class="line-chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="成绩时间分布直方图（${kind.label}）">
          ${grid}<line x1="${X0}" y1="${YB}" x2="${X1}" y2="${YB}" class="chart-base"/>
          ${bars}${xAx}
        </svg>
        <p class="bar-legend">每格 ${stepTxt} · 柱高 = 该时间段内的成绩个数${dnf ? ` · <span class="dnf-x">✕</span>DNF ${dnf} 次未计入` : ''} · 悬停柱可查看个数</p>`;
      }

      /* 折线图：按所选数据源绘制趋势（DNF 断线） */
      function trendChartSVG() {
        const kind = DATA_KINDS.find((k) => k.id === hdata);
        const pts = buildDataset(hdata);
        const vals = pts.map((p) => p.v);
        const finite = vals.filter((v) => isFinite(v));
        if (!finite.length) return '<div class="chart-empty">该数据源下全部为 DNF，暂无可绘制的趋势</div>';
        let min0 = Math.min(...finite);
        let max0 = Math.max(...finite);
        if (max0 - min0 < 1e-9) {
          max0 = min0 + Math.max(1, min0 * 0.1);
          min0 = Math.max(0, min0 - Math.max(1, min0 * 0.1));
        }
        const span = max0 - min0;
        const lo = min0 - span * 0.12;
        const hi = max0 + span * 0.12;
        const W = 660, H = 230, PL = 54, PR = 14, PT = 30, PB = 26;
        const n = pts.length;
        const X = (i) => (n === 1 ? PL + (W - PL - PR) / 2 : PL + (i * (W - PL - PR)) / (n - 1));
        const Y = (v) => PT + ((hi - v) / (hi - lo)) * (H - PT - PB);
        const bestVal = Math.min(...finite);

        const segs = [];
        let cur = [];
        vals.forEach((v, i) => {
          if (isFinite(v)) cur.push(i);
          else if (cur.length) { segs.push(cur); cur = []; }
        });
        if (cur.length) segs.push(cur);
        const lines = segs.filter((s) => s.length > 1).map((s) =>
          `<polyline points="${s.map((i) => `${X(i).toFixed(1)},${Y(vals[i]).toFixed(1)}`).join(' ')}" class="chart-line"/>`
        ).join('');

        const dots = pts.map((p, i) => {
          if (!isFinite(p.v)) return `<text x="${X(i).toFixed(1)}" y="17" class="chart-dnf" text-anchor="middle">✕</text>`;
          const cls = Math.abs(p.v - bestVal) < 1e-9 ? ' best' : '';
          return `<circle cx="${X(i).toFixed(1)}" cy="${Y(p.v).toFixed(1)}" r="4.5" class="chart-dot${cls}">
            <title>${p.title}</title></circle>`;
        }).join('');

        /* x 轴：按场次标日期；「所有成绩」模式画场次分隔虚线 */
        const step = Math.ceil(rounds.length / 9);
        let xAx = '';
        let seps = '';
        if (hdata === 'all') {
          rounds.forEach((r, ri) => {
            const idxs = pts.map((p, i) => (p.ri === ri ? i : -1)).filter((i) => i >= 0);
            if (!idxs.length) return;
            if (ri > 0 && idxs[0] > 0) {
              const sx = (X(idxs[0] - 1) + X(idxs[0])) / 2;
              seps += `<line x1="${sx.toFixed(1)}" y1="${PT - 6}" x2="${sx.toFixed(1)}" y2="${H - PB}" class="chart-sep"/>`;
            }
            if (ri % step === 0) {
              const c = (idxs[0] + idxs[idxs.length - 1]) / 2;
              xAx += `<text x="${X(c).toFixed(1)}" y="${H - 8}" class="chart-ax" text-anchor="middle">${shortDate(r.date)}</text>`;
            }
          });
        } else {
          xAx = rounds.map((r, i) => (i % step === 0
            ? `<text x="${X(i).toFixed(1)}" y="${H - 8}" class="chart-ax" text-anchor="middle">${shortDate(r.date)}</text>`
            : '')).join('');
        }

        const yAx = `
          <text x="6" y="${Y(max0).toFixed(1)}" class="chart-ax" dominant-baseline="middle">${esc(fmtTime(max0, ''))}</text>
          <text x="6" y="${Y(min0).toFixed(1)}" class="chart-ax" dominant-baseline="middle">${esc(fmtTime(min0, ''))}</text>
          <line x1="${PL - 6}" y1="${Y(max0).toFixed(1)}" x2="${W - PR}" y2="${Y(max0).toFixed(1)}" class="chart-axis"/>
          <line x1="${PL - 6}" y1="${Y(min0).toFixed(1)}" x2="${W - PR}" y2="${Y(min0).toFixed(1)}" class="chart-axis"/>`;

        return `<svg class="line-chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="成绩趋势折线图（${kind.label}）">
          ${yAx}${seps}${lines}${dots}${xAx}
        </svg>
        <p class="bar-legend">每个点 = ${kind.pt} · <span class="lg-dot best"></span>最好 · <span class="dnf-x">✕</span>DNF（断线）</p>`;
      }

      /* 逐场明细（旧 → 新），个人最好单次 chip 高亮 */
      const bestEff = Math.min(...flatEff.filter((v) => isFinite(v)).concat([Infinity]));
      const rowsHtml = rounds.map((r) => {
        const chips = r.times.map((t) => {
          const v = eff(t);
          const isBest = isFinite(v) && Math.abs(v - bestEff) < 1e-9;
          return `<span class="t-chip mono${t.pen === 'dnf' ? ' t-dnf' : ''}${isBest ? ' t-best' : ''}">${esc(fmtTime(t.val, t.pen))}</span>`;
        }).join('');
        return `
        <div class="eh-row">
          <span class="eh-date mono">${shortDate(r.date)}</span>
          <a class="eh-comp" href="#/comp/${r.compId}">${esc(r.compName)}</a>
          <span class="t-chips">${chips}</span>
          <span class="eh-ao5 mono">${aoName} ${esc(r.st.ao5Disp)}</span>
          <span class="eh-rank">${r.rank ? `第 ${r.rank} 名` : '—'}</span>
        </div>`;
      }).join('');

      $modalRoot.innerHTML = `
        <div class="modal-overlay">
          <div class="modal player-modal">
            <header class="m-head">
              <h3>👤 ${esc(pName)} <span class="m-head-sub">· ${ev.icon} ${esc(ev.name)} · 历史成绩</span></h3>
              <div class="m-head-right">
                <button class="icon-btn" data-close title="关闭">✕</button>
              </div>
            </header>
            <div class="eh-viewbar">
              <div class="m-tabs">
                <button class="m-tab on" data-hview="bar">📊 时间分布</button>
                <button class="m-tab" data-hview="line">📈 折线图</button>
              </div>
              <div class="seg eh-data" role="group" aria-label="图表数据源">
                ${DATA_KINDS.map((k) => `<button class="seg-btn${k.id === hdata ? ' on' : ''}" data-hdata="${k.id}">${k.label}</button>`).join('')}
              </div>
            </div>
            <div class="m-body">
              <div class="pe-stats">
                <div class="pe-stat"><span>参赛场次</span><b>${rounds.length} 场</b></div>
                <div class="pe-stat"><span>还原次数</span><b>${solved} / ${flat.length}</b></div>
                <div class="pe-stat"><span>单次最好</span><b class="mono">${esc(e.bestDisp)}</b></div>
                <div class="pe-stat"><span>${aoName} 最好</span><b class="mono">${esc(e.ao5Disp)}</b></div>
              </div>
              <div class="chart-box" id="eh-chart">${hview === 'bar' ? histChartSVG() : trendChartSVG()}</div>
              <h4 class="eh-title">🗒 逐场明细（旧 → 新）</h4>
              <div class="eh-list">${rowsHtml}</div>
            </div>
          </div>
        </div>`;

      const overlay = $modalRoot.firstElementChild;
      const chartBox = overlay.querySelector('#eh-chart');
      const onKey = (evx) => { if (evx.key === 'Escape') close(); };
      function close() {
        overlay.classList.add('closing');
        setTimeout(() => { $modalRoot.innerHTML = ''; }, 170);
        document.removeEventListener('keydown', onKey);
      }
      document.addEventListener('keydown', onKey);
      overlay.addEventListener('click', (evx) => { if (evx.target === overlay) close(); });
      overlay.querySelectorAll('[data-close]').forEach((b) => b.addEventListener('click', close));
      overlay.querySelectorAll('[data-hview]').forEach((t) => {
        t.addEventListener('click', () => {
          if (hview === t.dataset.hview) return;
          hview = t.dataset.hview;
          overlay.querySelectorAll('[data-hview]').forEach((x) => x.classList.toggle('on', x === t));
          chartBox.innerHTML = hview === 'bar' ? histChartSVG() : trendChartSVG();
        });
      });
      overlay.querySelectorAll('[data-hdata]').forEach((t) => {
        t.addEventListener('click', () => {
          if (hdata === t.dataset.hdata) return;
          hdata = t.dataset.hdata;
          overlay.querySelectorAll('[data-hdata]').forEach((x) => x.classList.toggle('on', x === t));
          chartBox.innerHTML = hview === 'bar' ? histChartSVG() : trendChartSVG();
        });
      });
    }

    document.querySelector('.pb-table tbody').addEventListener('click', (evx) => {
      const tr = evx.target.closest('tr[data-evhist]');
      if (!tr || evx.target.closest('a, button')) return;
      openEventHistory(name, tr.dataset.evhist);
    });
  }

  /* ---------------- 全局事件（卡片跳转 / 删除比赛） ---------------- */
  document.addEventListener('click', (e) => {
    const open = e.target.closest('[data-open]');
    if (open) { location.hash = open.dataset.open; return; }
    const del = e.target.closest('[data-del]');
    if (del) {
      const comp = D.getComp(del.dataset.del);
      if (!comp) return;
      e.stopPropagation();
      confirmDialog({
        title: '删除比赛',
        text: `将永久删除「<b>${esc(comp.name)}</b>」及其全部成绩记录，无法恢复。`,
        okText: '删除',
        danger: true,
      }).then((ok) => {
        if (!ok) return;
        D.deleteCompetition(comp.id);
        toast('比赛已删除');
        renderHome();
      });
    }
  });

  /* ---------------- 启动 ---------------- */
  render();
})();
