/* =========================================================
 * 导出层：Excel（SheetJS 本地库）+ PDF（Canvas 绘制 → jsPDF）
 * PDF 采用「表格绘制到高分辨率画布 → 嵌入 JPEG」方案，
 * 中文由浏览器系统字体渲染，无需内嵌字体。
 * ========================================================= */
(function () {
  'use strict';

  const A4W = 595.28;   // pt
  const A4H = 841.89;  // pt
  const SC = 2;        // 画布放大倍数（清晰度）
  const M = 30;        // 页边距 pt
  const ROWS_PER_PAGE = 20;

  const FONT = '"PingFang SC","Microsoft YaHei","Noto Sans CJK SC","Source Han Sans SC",sans-serif';

  function sanitize(name) {
    return String(name).replace(/[\\/:*?"<>|]/g, '_').trim() || '未命名';
  }
  const nowStr = () => new Date().toLocaleString('zh-CN', { hour12: false });

  /* ======================= Excel ======================= */

  /* 项目计次口径：3 次制项目（6x6/7x7/4bld/5bld/3bld）平均 = 三次直接平均 */
  const attemptsOf = (ev) => (ev && ev.attempts) || 5;
  const avgLabel = (ev) => (attemptsOf(ev) === 3 ? 'Ao3' : 'Ao5');

  function ruleLines(ev) {
    const n = attemptsOf(ev);
    if (ev && ev.rankMode === 'single') {
      return [
        `说明：最好 = ${n} 次中最短用时；Ao3 = 三次直接平均（不去头去尾），任一次 DNF 平均记 DNF。`,
        '惩罚：+2 = 成绩加 2 秒（显示如 8.62+）；DNF = 本次未完成。',
        '排序规则：先比单次最好（越小越好），相同再比 Ao3，仍相同并列。',
      ];
    }
    if (n === 3) {
      return [
        '说明：最好 = 三次中最短用时；Ao3 = 三次直接平均（不去头去尾），任一次 DNF 平均记 DNF。',
        '惩罚：+2 = 成绩加 2 秒（显示如 8.62+）；DNF = 本次未完成。',
        '排序规则：先比 Ao3（越小越好），Ao3 无效者排最后，其间比单次最好。',
      ];
    }
    return [
      '说明：最好 = 五次中最短用时；Ao5 = 去除最好与最坏成绩后，中间三次的平均。',
      '惩罚：+2 = 成绩加 2 秒（显示如 8.62+）；DNF = 本次未完成；一轮两次 DNF 则 Ao5 记为 DNF。',
      '排序规则：先比 Ao5（越小越好），Ao5 无效（DNF）者排最后，其间比单次最好。',
    ];
  }

  function buildSheet(comp, ev, rows) {
    const D = window.CubeData;
    const n = attemptsOf(ev);
    const aoa = [
      ['SJTU 魔方社周赛 · 赛果报告'],
      ['比赛', comp.name],
      ['日期', comp.date],
      ['项目', ev.name],
      ['状态', comp.ended ? '已结束' : '进行中'],
      [],
      ['排名', '选手', '最好', avgLabel(ev),
        ...Array.from({ length: n }, (_, i) => `第${i + 1}次`)],
    ];
    rows.forEach((r) => {
      aoa.push([
        r.rank,
        r.name,
        r.bestDisp,
        r.ao5Disp,
        ...r.times.map((t) => D.fmtTime(t.val, t.pen)),
      ]);
    });
    aoa.push([]);
    ruleLines(ev).forEach((line) => aoa.push([line]));
    aoa.push(['导出时间', nowStr()]);

    const ws = XLSX.utils.aoa_to_sheet(aoa);
    ws['!cols'] = [
      { wch: 6 }, { wch: 16 }, { wch: 10 }, { wch: 10 },
      ...Array.from({ length: n }, () => ({ wch: 10 })),
    ];
    return ws;
  }

  /** 导出单个项目赛果为 .xlsx */
  function eventExcel(comp, evId) {
    const D = window.CubeData;
    const ev = D.eventById(evId);
    const rows = D.rankList(comp, evId);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, buildSheet(comp, ev, rows), ev.name);
    XLSX.writeFile(wb, `SJTU魔方社周赛_${sanitize(comp.name)}_${ev.name}_赛果.xlsx`);
  }

  /** 导出整场比赛（每个项目一个 Sheet） */
  function allExcel(comp) {
    const D = window.CubeData;
    const wb = XLSX.utils.book_new();
    comp.events.forEach((evId) => {
      const ev = D.eventById(evId);
      const rows = D.rankList(comp, evId);
      XLSX.utils.book_append_sheet(wb, buildSheet(comp, ev, rows), ev.name);
    });
    XLSX.writeFile(wb, `SJTU魔方社周赛_${sanitize(comp.name)}_全部赛果.xlsx`);
  }

  /** PDF 页脚图例（单行精简版，按项目口径） */
  function legendOf(ev) {
    const n = attemptsOf(ev);
    if (ev && ev.rankMode === 'single') {
      return '最好 = 三次中最短 ｜ Ao3 = 三次直接平均，任一次DNF → Ao3=DNF ｜ +2 = 成绩+2秒 ｜ 排序：先单次最好后Ao3';
    }
    if (n === 3) {
      return '最好 = 三次中最短 ｜ Ao3 = 三次直接平均（不去头去尾），任一次DNF → Ao3=DNF ｜ +2 = 成绩+2秒 ｜ 排序：先Ao3后单次最好';
    }
    return '最好 = 五次中最短 ｜ Ao5 = 去除最好与最坏后中间三次平均 ｜ +2 = 成绩+2秒 ｜ 两次DNF → Ao5=DNF ｜ 排序：先Ao5后单次最好';
  }

  /* ======================= PDF ======================= */

  /** 表格列定义（按项目计次动态生成：3 次制 3 列，其余 5 列） */
  function colsFor(ev) {
    const n = attemptsOf(ev);
    const cols = [
      { w: 36, head: '排名' },
      { w: 112, head: '选手' },
      { w: 66, head: '最好' },
      { w: 66, head: avgLabel(ev) },
    ];
    const fixed = cols.reduce((s, c) => s + c.w, 0);
    const t = (A4W - 2 * M - fixed) / n;
    for (let i = 0; i < n; i++) cols.push({ w: t, head: `第${i + 1}次` });
    return cols;
  }

  function rankColor(rank) {
    if (rank === 1) return '#b45309';
    if (rank === 2) return '#64748b';
    if (rank === 3) return '#b45309';
    return '#374151';
  }

  /** 绘制一页赛果到画布 */
  function drawEventPage(comp, ev, rows, pageIdx, totalPages) {
    const D = window.CubeData;
    const COLS = colsFor(ev);
    const cv = document.createElement('canvas');
    cv.width = Math.round(A4W * SC);
    cv.height = Math.round(A4H * SC);
    const ctx = cv.getContext('2d');
    ctx.scale(SC, SC);

    /* 背景 */
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, A4W, A4H);

    /* 头部横幅 */
    const grad = ctx.createLinearGradient(0, 0, A4W, 90);
    grad.addColorStop(0, '#312e81');
    grad.addColorStop(1, '#6d28d9');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, A4W, 88);
    ctx.fillStyle = '#ffffff';
    ctx.font = `bold 20px ${FONT}`;
    ctx.textBaseline = 'alphabetic';
    ctx.fillText('SJTU 魔方社周赛 · 赛果报告', M, 38);
    ctx.font = `12px ${FONT}`;
    ctx.fillStyle = 'rgba(255,255,255,0.88)';
    ctx.fillText(
      `${comp.name} ｜ ${comp.date} ｜ ${ev.name}（${comp.ended ? '已结束' : '进行中'}）`,
      M, 62
    );

    /* 表格几何 */
    const xs = [];
    let x = M;
    COLS.forEach((c) => { xs.push(x); x += c.w; });
    const tw = A4W - 2 * M;
    const y0 = 122;
    const headH = 30;
    const rowH = 29;

    /* 表头 */
    ctx.fillStyle = '#1f2937';
    ctx.fillRect(M, y0, tw, headH);
    ctx.fillStyle = '#f9fafb';
    ctx.font = `bold 11px ${FONT}`;
    ctx.textBaseline = 'middle';
    COLS.forEach((c, i) => {
      const w = ctx.measureText(c.head).width;
      ctx.fillText(c.head, xs[i] + c.w / 2 - w / 2, y0 + headH / 2 + 0.5);
    });

    if (!rows.length) {
      ctx.fillStyle = '#6b7280';
      ctx.font = `13px ${FONT}`;
      const msg = '该项目暂无成绩记录';
      ctx.fillText(msg, A4W / 2 - ctx.measureText(msg).width / 2, y0 + 60);
    }

    /* 行 */
    let y = y0 + headH;
    rows.forEach((r, idx) => {
      if (idx % 2 === 1) {
        ctx.fillStyle = '#f4f5f7';
        ctx.fillRect(M, y, tw, rowH);
      }
      const midY = y + rowH / 2 + 0.5;
      ctx.textBaseline = 'middle';

      /* 排名 */
      ctx.font = `bold ${r.rank <= 3 ? 13 : 11}px ${FONT}`;
      ctx.fillStyle = rankColor(r.rank);
      const rk = String(r.rank);
      ctx.fillText(rk, xs[0] + COLS[0].w / 2 - ctx.measureText(rk).width / 2, midY);

      /* 选手 */
      ctx.font = `bold 12px ${FONT}`;
      ctx.fillStyle = '#111827';
      ctx.fillText(r.name, xs[1] + 10, midY);

      /* 最好 / 平均 */
      ctx.font = `11px ${FONT}`;
      ctx.fillStyle = '#1f2937';
      const bestT = r.bestDisp;
      ctx.fillText(bestT, xs[2] + COLS[2].w / 2 - ctx.measureText(bestT).width / 2, midY);
      ctx.font = `bold 11px ${FONT}`;
      const aoT = r.ao5Disp;
      ctx.fillText(aoT, xs[3] + COLS[3].w / 2 - ctx.measureText(aoT).width / 2, midY);

      /* 各次成绩 */
      ctx.font = `11px ${FONT}`;
      r.times.forEach((t, i) => {
        let fill = '#4b5563';
        let bold = false;
        if (i === r.bestIdx) { fill = '#059669'; bold = true; }
        else if (i === r.worstIdx && r.markWorst) { fill = '#e11d48'; }
        else if (t.pen === 'dnf') { fill = '#9ca3af'; }
        ctx.font = `${bold ? 'bold ' : ''}11px ${FONT}`;
        ctx.fillStyle = fill;
        const txt = D.fmtTime(t.val, t.pen);
        const ci = 4 + i;
        ctx.fillText(
          txt, xs[ci] + COLS[ci].w / 2 - ctx.measureText(txt).width / 2, midY
        );
      });

      y += rowH;
    });

    /* 表格边框与竖线 */
    const tableBottom = y0 + headH + Math.max(rows.length, 0) * rowH;
    ctx.strokeStyle = '#d1d5db';
    ctx.lineWidth = 1;
    ctx.strokeRect(M + 0.5, y0 + 0.5, tw - 1, tableBottom - y0 - 1);
    ctx.strokeStyle = '#e5e7eb';
    xs.forEach((cx, i) => {
      if (i === 0) return;
      ctx.beginPath();
      ctx.moveTo(cx + 0.5, y0);
      ctx.lineTo(cx + 0.5, tableBottom);
      ctx.stroke();
    });
    for (let ry = y0 + headH; ry < tableBottom - 0.5; ry += rowH) {
      ctx.beginPath();
      ctx.moveTo(M, ry + 0.5);
      ctx.lineTo(M + tw, ry + 0.5);
      ctx.stroke();
    }

    /* 图例 */
    ctx.font = `10px ${FONT}`;
    ctx.fillStyle = '#6b7280';
    ctx.fillText(legendOf(ev), M, tableBottom + 24);

    /* 页脚 */
    ctx.fillStyle = '#9ca3af';
    ctx.font = `10px ${FONT}`;
    ctx.fillText(`导出时间 ${nowStr()} · SJTU 魔方社周赛成绩管理系统`, M, A4H - 24);
    const pg = `第 ${pageIdx + 1} / ${totalPages} 页`;
    ctx.fillText(pg, A4W - M - ctx.measureText(pg).width, A4H - 24);

    return cv;
  }

  function chunkRows(rows, per) {
    if (!rows.length) return [[]];
    const chunks = [];
    for (let i = 0; i < rows.length; i += per) chunks.push(rows.slice(i, i + per));
    return chunks;
  }

  /** 导出单个项目赛果为 PDF */
  function eventPDF(comp, evId) {
    const D = window.CubeData;
    const ev = D.eventById(evId);
    const rows = D.rankList(comp, evId);
    const chunks = chunkRows(rows, ROWS_PER_PAGE);
    const pdf = new window.jspdf.jsPDF({ unit: 'pt', format: 'a4', orientation: 'portrait' });
    chunks.forEach((chunk, i) => {
      if (i) pdf.addPage();
      const cv = drawEventPage(comp, ev, chunk, i, chunks.length);
      pdf.addImage(cv.toDataURL('image/jpeg', 0.92), 'JPEG', 0, 0, A4W, A4H);
    });
    pdf.save(`SJTU魔方社周赛_${sanitize(comp.name)}_${ev.name}_赛果.pdf`);
  }

  /** 导出整场比赛（分项目分页） */
  function allPDF(comp) {
    const D = window.CubeData;
    const pdf = new window.jspdf.jsPDF({ unit: 'pt', format: 'a4', orientation: 'portrait' });
    const evChunks = comp.events.map((evId) => ({
      ev: D.eventById(evId),
      chunks: chunkRows(D.rankList(comp, evId), ROWS_PER_PAGE),
    }));
    const totalPages = evChunks.reduce((s, e) => s + e.chunks.length, 0);
    let page = 0;
    evChunks.forEach((ec) => {
      ec.chunks.forEach((chunk) => {
        if (page) pdf.addPage();
        const cv = drawEventPage(comp, ec.ev, chunk, page, totalPages);
        pdf.addImage(cv.toDataURL('image/jpeg', 0.92), 'JPEG', 0, 0, A4W, A4H);
        page++;
      });
    });
    pdf.save(`SJTU魔方社周赛_${sanitize(comp.name)}_全部赛果.pdf`);
  }

  window.CubeExport = { eventExcel, allExcel, eventPDF, allPDF };
})();
