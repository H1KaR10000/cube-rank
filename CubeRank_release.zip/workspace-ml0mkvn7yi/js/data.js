/* =========================================================
 * 数据层：状态存储、成绩计算、排行榜逻辑
 * 纯前端，数据持久化在浏览器 localStorage
 * 成绩格式：m:ss.xx / m:s.xxx / 秒数，支持 +2 与 DNF 惩罚
 * ========================================================= */
(function () {
  'use strict';

  const STORE_KEY = 'sjtu-cube-weekly-v1';

  /* ---------------- 项目定义与图标工厂 ----------------
   * 图标效仿 WCA 各项目深蓝扁平风格：NxN 用方格网，
   * 盲拧加遮挡条，多盲加 N 标识，其余用几何图形。 */

  const icSvg = (inner, extra = '') =>
    `<svg class="ev-ic" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg" fill="currentColor"${extra ? ' ' + extra : ''}>${inner}</svg>`;

  const R2 = (x) => Math.round(x * 100) / 100;

  /** n×n 方格网 */
  function icGrid(n) {
    const gap = n >= 5 ? 1.5 : 2;
    const c = (44 - (n - 1) * gap) / n;
    const start = (48 - (n * c + (n - 1) * gap)) / 2;
    let s = '';
    for (let i = 0; i < n; i++) {
      for (let j = 0; j < n; j++) {
        s += `<rect x="${R2(start + i * (c + gap))}" y="${R2(start + j * (c + gap))}" width="${R2(c)}" height="${R2(c)}" rx="1.3"/>`;
      }
    }
    return icSvg(s);
  }

  /** 盲拧：方格网 + 遮挡条（多盲再加 N 标识） */
  function icBld(n, withN) {
    const inner = icGrid(n).replace('</svg>', '') +
      '<rect x="5" y="20" width="38" height="8" rx="4"/>' +
      (withN ? '<text x="24" y="27.2" font-size="7.5" font-weight="700" text-anchor="middle" fill="#fff" font-family="inherit">N</text>' : '') +
      '</svg>';
    return inner;
  }

  /** 最少步：拼图碎片 */
  function icFmc() {
    return icSvg('<path d="M8 14 h12 a5 5 0 1 1 10 0 h10 v26 h-32 z"/>');
  }

  /** 单手：小魔方 + 手 */
  function icOh() {
    let cube = '';
    for (let i = 0; i < 3; i++) {
      for (let j = 0; j < 3; j++) {
        cube += `<rect x="${17 + i * 5}" y="${3 + j * 5}" width="4" height="4" rx="1"/>`;
      }
    }
    return icSvg(cube +
      '<rect x="14.5" y="21" width="3.6" height="10" rx="1.8"/>' +
      '<rect x="20.2" y="21" width="3.6" height="10" rx="1.8"/>' +
      '<rect x="25.9" y="21" width="3.6" height="10" rx="1.8"/>' +
      '<rect x="31.6" y="21" width="3.6" height="10" rx="1.8"/>' +
      '<rect x="9" y="27" width="3.6" height="9" rx="1.8"/>' +
      '<rect x="13" y="30" width="22" height="10" rx="4"/>');
  }

  /** 魔表：表盘 + 指针 */
  function icClock() {
    let dots = '';
    for (let k = 0; k < 12; k++) {
      const a = (k * 30 * Math.PI) / 180;
      dots += `<circle cx="${R2(24 + 13.5 * Math.cos(a))}" cy="${R2(24 + 13.5 * Math.sin(a))}" r="1.9"/>`;
    }
    return icSvg(
      `<circle cx="24" cy="24" r="19" fill="none" stroke="currentColor" stroke-width="4"/>` + dots +
      '<path d="M24 24 L24 14.5" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" fill="none"/>' +
      '<path d="M24 24 L30.5 27.5" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" fill="none"/>');
  }

  const polyPts = (cx, cy, r, n, startDeg) => {
    const pts = [];
    for (let k = 0; k < n; k++) {
      const a = ((startDeg + (k * 360) / n) * Math.PI) / 180;
      pts.push(`${R2(cx + r * Math.cos(a))},${R2(cy + r * Math.sin(a))}`);
    }
    return pts.join(' ');
  };

  /** 五魔方：双层五边形 */
  function icMega() {
    return icSvg(
      `<polygon points="${polyPts(24, 25, 18, 5, -90)}" fill="none" stroke="currentColor" stroke-width="3" stroke-linejoin="round"/>` +
      `<polygon points="${polyPts(24, 25, 8.5, 5, -54)}" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/>`);
  }

  /** 金字塔：大三角 + 中位倒三角 */
  function icPyra() {
    return icSvg(
      '<path d="M24 6 L42 38 H6 Z" fill="none" stroke="currentColor" stroke-width="3" stroke-linejoin="round"/>' +
      '<path d="M33 22 H15 L24 38 Z" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linejoin="round"/>');
  }

  /** 斜转：菱形 + 十字切分 */
  function icSkewb() {
    return icSvg(
      '<path d="M24 6 L42 24 L24 42 L6 24 Z" fill="none" stroke="currentColor" stroke-width="3" stroke-linejoin="round"/>' +
      '<path d="M24 6 V42 M6 24 H42" stroke="currentColor" stroke-width="2"/>');
  }

  /** SQ-1：八角星 */
  function icSq1() {
    let pts = [];
    for (let k = 0; k < 16; k++) {
      const r = k % 2 === 0 ? 19 : 9;
      const a = ((k * 22.5 - 90) * Math.PI) / 180;
      pts.push(`${R2(24 + r * Math.cos(a))},${R2(24 + r * Math.sin(a))}`);
    }
    return icSvg(`<polygon points="${pts.join(' ')}"/>`);
  }

  const EVENTS = [
    { id: '3x3',   name: '三阶',   tag: '3×3×3', icon: icGrid(3),      color: '#34d399' },
    { id: '2x2',   name: '二阶',   tag: '2×2×2', icon: icGrid(2),      color: '#38bdf8' },
    { id: '4x4',   name: '四阶',   tag: '4×4×4', icon: icGrid(4),      color: '#a78bfa' },
    { id: '5x5',   name: '五阶',   tag: '5×5×5', icon: icGrid(5),      color: '#f472b6' },
    { id: '6x6',   name: '六阶',   tag: '6×6×6', icon: icGrid(6), attempts: 3, color: '#fbbf24' },
    { id: '7x7',   name: '七阶',   tag: '7×7×7', icon: icGrid(7), attempts: 3, color: '#fb7185' },
    { id: '3bld',  name: '三盲',   tag: '3BLD',  icon: icBld(3), attempts: 3, rankMode: 'single', color: '#818cf8' },
    { id: 'fmc',   name: '最少步', tag: 'FMC',   icon: icFmc(),        color: '#4ade80' },
    { id: 'oh',    name: '单手',   tag: 'OH',    icon: icOh(),         color: '#f97316' },
    { id: 'clock', name: '魔表',   tag: 'Clock', icon: icClock(),      color: '#facc15' },
    { id: 'mega',  name: '五魔方', tag: 'Megaminx', icon: icMega(),    color: '#2dd4bf' },
    { id: 'pyra',  name: '金字塔', tag: 'Pyraminx', icon: icPyra(),    color: '#e879f9' },
    { id: 'skewb', name: '斜转',   tag: 'Skewb', icon: icSkewb(),      color: '#60a5fa' },
    { id: 'sq1',   name: 'SQ-1',   tag: 'Square-1', icon: icSq1(),     color: '#f87171' },
    { id: '4bld',  name: '四盲',   tag: '4BLD',  icon: icBld(4), attempts: 3, rankMode: 'single', color: '#c084fc' },
    { id: '5bld',  name: '五盲',   tag: '5BLD',  icon: icBld(5), attempts: 3, rankMode: 'single', color: '#fda4af' },
    { id: 'mbld',  name: '多盲',   tag: 'MBLD',  icon: icBld(3, true), color: '#f43f5e' },
  ];
  const eventById = (id) => EVENTS.find((e) => e.id === id) || null;

  /* 惩罚类型：''（无）、'+2'（加 2 秒）、'dnf'（本次未完成） */
  const PEN_NONE = '';
  const PEN_PLUS2 = '+2';
  const PEN_DNF = 'dnf';
  function normPen(p) {
    if (p === '+2') return PEN_PLUS2;
    if (p === 'dnf') return PEN_DNF;
    return PEN_NONE;
  }

  /* ---------------- 状态与持久化 ---------------- */
  let state = { competitions: [] };

  function load() {
    try {
      const raw = localStorage.getItem(STORE_KEY);
      if (raw) state = JSON.parse(raw) || {};
    } catch (e) { /* 损坏数据视为空 */ }
    if (!Array.isArray(state.competitions)) state.competitions = [];
    migrate(state);
  }

  /** 旧数据迁移：times 元素补 pen 字段（旧数据无惩罚概念） */
  function migrate(st) {
    let dirty = false;
    (st.competitions || []).forEach((c) => {
      Object.values(c.results || {}).forEach((list) => {
        (list || []).forEach((r) => {
          if (Array.isArray(r.times)) {
            r.times.forEach((t) => {
              if (t && typeof t === 'object' && t.pen == null) { t.pen = PEN_NONE; dirty = true; }
              if (t && typeof t === 'object' && t.pen != null) t.pen = normPen(t.pen);
            });
          }
        });
      });
    });
    if (dirty) save();
  }

  function save() {
    try { localStorage.setItem(STORE_KEY, JSON.stringify(state)); }
    catch (e) { /* 存储失败静默（隐私模式等） */ }
  }

  function uid() {
    return 'c_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  }

  /* ---------------- 比赛管理 ---------------- */
  function createCompetition({ name, date, events }) {
    const comp = {
      id: uid(),
      name: String(name).trim(),
      date,
      createdAt: Date.now(),
      ended: false,
      endedAt: null,
      events: events.slice(),
      results: {},
    };
    events.forEach((evId) => { comp.results[evId] = []; });
    state.competitions.unshift(comp);
    save();
    return comp;
  }

  const getComp = (id) => state.competitions.find((c) => c.id === id) || null;

  function deleteCompetition(id) {
    state.competitions = state.competitions.filter((c) => c.id !== id);
    save();
  }

  function endCompetition(comp) {
    comp.ended = true;
    comp.endedAt = Date.now();
    save();
  }
  function reopenCompetition(comp) {
    comp.ended = false;
    comp.endedAt = null;
    save();
  }

  /** 比赛进行中追加项目（不允许重复、不允许未知项目） */
  function addEvent(comp, evId) {
    if (!eventById(evId)) return false;
    if (comp.events.includes(evId)) return false;
    comp.events.push(evId);
    if (!comp.results) comp.results = {};
    if (!comp.results[evId]) comp.results[evId] = [];
    save();
    return true;
  }

  /** 拖拽排序：按新顺序整体覆写 comp.events（ids 必须是其全量排列） */
  function moveEvents(comp, ids) {
    if (!Array.isArray(ids) || ids.length !== comp.events.length) return false;
    const set = new Set(ids);
    if (set.size !== ids.length || comp.events.some((id) => !set.has(id))) return false;
    comp.events = ids.slice();
    save();
    return true;
  }

  /** 删除项目（连带该项目全部成绩），返回被删掉的记录条数 */
  function removeEvent(comp, evId) {
    const i = comp.events.indexOf(evId);
    if (i < 0) return -1;
    const removed = (comp.results[evId] || []).length;
    comp.events.splice(i, 1);
    if (comp.results) delete comp.results[evId];
    save();
    return removed;
  }

  /* ---------------- 成绩录入与校验 ---------------- */
  /* 支持三种写法：
     ① 纯秒数：      61.59 / 8 / 9.58517（小数任意位，超两位去尾）
     ② 分:秒：       1:01.59 / 1:1.59 / 1:01（秒部分须 < 60）
     ③ 组合上限：    总时长 > 0 且 ≤ 3600 秒
     小数点后超过两位时按"去尾"保留两位（不四舍五入）。 */
  const TIME_RE = /^(\d{1,3})(?::(\d{1,2}(?:\.\d+)?)|\.(\d+))?$/;

  /** 校验单条成绩输入，返回 {ok, raw, val} 或 {ok:false, reason} */
  function parseTime(str) {
    const s = String(str == null ? '' : str).trim();
    const m = TIME_RE.exec(s);
    if (!m) {
      return { ok: false, reason: '格式：秒数（如 8.62）或 分:秒（如 1:01.59）' };
    }
    let val;
    if (m[2] !== undefined) {
      let secStr = m[2];
      const dot = secStr.indexOf('.');
      if (dot >= 0) secStr = secStr.slice(0, dot + 3); /* 去尾保留 2 位小数 */
      const sec = Number(secStr);
      if (sec >= 60) return { ok: false, reason: '秒数部分需小于 60（超过 60 秒请进位到分钟）' };
      val = Number(m[1]) * 60 + sec;
    } else if (m[3] !== undefined) {
      val = Number(m[1]) + Number('0.' + m[3].slice(0, 2)); /* 去尾保留 2 位小数 */
    } else {
      val = Number(m[1]);
    }
    if (!(val > 0)) return { ok: false, reason: '必须大于 0 秒' };
    if (val > 3600) return { ok: false, reason: '不能超过 3600 秒（60:00.00）' };
    return { ok: true, raw: s, val: round2(val) };
  }

  /** 新增或更新某项目某选手的 5 次成绩
   *  entries: [{raw, val, pen} × 5]，pen ∈ '' / '+2' / 'dnf'
   *  DNF 次允许时间为空（val 记 0，计算时忽略） */
  function upsertRecord(comp, eventId, playerName, entries) {
    if (!comp.results[eventId]) comp.results[eventId] = [];
    const list = comp.results[eventId];
    const name = String(playerName).trim();
    const rec = {
      name,
      times: entries.map((e) => ({
        raw: e.raw == null ? '' : String(e.raw),
        val: Number(e.val) || 0,
        pen: normPen(e.pen),
      })),
      updatedAt: Date.now(),
    };
    const i = list.findIndex((r) => r.name === name);
    if (i >= 0) list[i] = rec; else list.push(rec);
    save();
    return rec;
  }

  function deleteRecord(comp, eventId, playerName) {
    if (!comp.results[eventId]) return;
    comp.results[eventId] = comp.results[eventId].filter((r) => r.name !== playerName);
    save();
  }

  /* ---------------- 计算与排行 ---------------- */
  const EPS = 1e-9;

  /** 某次成绩的有效用时：DNF = Infinity，+2 = val + 2 */
  function effOf(t) {
    if (t.pen === PEN_DNF) return Infinity;
    return t.val + (t.pen === PEN_PLUS2 ? 2 : 0);
  }

  /**
   * 统一显示格式：
   *   < 60 秒        → 8.62 / 9.50（两位小数）
   *   ≥ 60 秒        → 1:01.59（分钟不补零，秒两位 + 两位小数）
   *   +2 惩罚        → 8.62+
   *   DNF            → DNF
   */
  function fmtTime(val, pen) {
    if (pen === PEN_DNF) return 'DNF';
    const v = (pen === PEN_PLUS2 ? val + 2 : val) * 100;
    const cs = Math.round(v);            /* 厘秒，规避浮点尾差 */
    let out;
    if (cs < 6000) {
      out = (cs / 100).toFixed(2);
    } else {
      const min = Math.floor(cs / 6000);
      const rest = cs - min * 6000;
      const sec = Math.floor(rest / 100);
      const frac = String(rest % 100).padStart(2, '0');
      out = `${min}:${String(sec).padStart(2, '0')}.${frac}`;
    }
    return pen === PEN_PLUS2 ? out + '+' : out;
  }

  /**
   * 单条记录统计。
   * @param rec 记录
   * @param ev  所属项目（可选）：attempts=3 → 只统计前三次且平均为直接三次平均（不去头去尾，
   *            任一次 DNF 平均记 DNF）；rankMode='single' → 名次先比单次最好。
   *            缺省按 5 次制（Ao5 去头去尾）处理。
   * 返回中 ao5/ao5Disp 字段泛指“该项目平均”（Ao5 或 Ao3）。
   */
  function stats(rec, ev) {
    const n = (ev && ev.attempts) || 5;
    const singleMode = !!(ev && ev.rankMode === 'single');
    const times = (rec.times || []).slice(0, n).map((t) => ({
      raw: t.raw == null ? '' : t.raw,
      val: Number(t.val) || 0,
      pen: normPen(t.pen),
    }));
    const effs = times.map(effOf);
    const dnfCount = times.filter((t) => t.pen === PEN_DNF).length;

    /* 最好：非 DNF 中有效用时最短者（DNF 永远不作为最好成绩） */
    let bestIdx = -1;
    for (let i = 0; i < effs.length; i++) {
      if (times[i].pen === PEN_DNF) continue;
      if (bestIdx < 0 || effs[i] < effs[bestIdx]) bestIdx = i;
    }
    /* 最坏：有效用时最长者（DNF = Infinity 天然排最后，并列取首个） */
    let worstIdx = 0;
    for (let i = 1; i < effs.length; i++) {
      if (effs[i] > effs[worstIdx]) worstIdx = i;
    }

    /* 平均：5 次制 = Ao5（去最好最坏取中间三次平均，DNF ≥ 2 → DNF）；
       3 次制 = Ao3（三次直接平均，不去头去尾，任一次 DNF → DNF） */
    let ao5 = Infinity;
    if (n === 3) {
      if (times.length >= 3 && dnfCount === 0) {
        ao5 = (effs[0] + effs[1] + effs[2]) / 3;
      }
    } else if (times.length >= 5 && dnfCount <= 1) {
      const arr = effs.slice().sort((a, b) => a - b);
      ao5 = (arr[1] + arr[2] + arr[3]) / 3;
    }

    const hasValid = bestIdx >= 0;
    const best = hasValid ? effs[bestIdx] : Infinity;

    /* 扩展统计（有效成绩 = 非 DNF 的含惩罚用时；DNF 视为无数据）：
       均值 / 样本标准差（n-1）/ 极差 / 均值的 95% 置信区间（t 分布，小样本） */
    const finite = effs.filter((v) => isFinite(v));
    const m = finite.length;
    const mean = m ? finite.reduce((s, v) => s + v, 0) / m : null;
    const sd = m >= 2
      ? Math.sqrt(finite.reduce((s, v) => s + (v - mean) * (v - mean), 0) / (m - 1))
      : null;
    const range = m >= 2 ? Math.max(...finite) - Math.min(...finite) : null;
    /* t(0.975, df) 临界值：df = m-1（m=2..5 覆盖单轮 5 次） */
    const T975 = { 1: 12.706, 2: 4.303, 3: 3.182, 4: 2.776 };
    let ci = null;
    if (m >= 2 && isFinite(sd)) {
      const t = T975[m - 1] != null ? T975[m - 1] : 1.96;
      const half = (t * sd) / Math.sqrt(m);
      ci = { lo: Math.max(0, mean - half), hi: mean + half, mean, n: m };
    }

    return {
      name: rec.name,
      times, effs,
      attempts: n,
      rankMode: singleMode ? 'single' : 'avg',
      avgMode: n === 3 ? 'mean3' : 'trim',
      best,
      bestIdx: hasValid ? bestIdx : 0,
      worstIdx,
      dnfCount,
      ao5,
      markWorst: n === 3 ? dnfCount === 0 && effs.length >= 2 : dnfCount <= 1,
      bestDisp: hasValid ? fmtTime(times[bestIdx].val, times[bestIdx].pen) : 'DNF',
      ao5Disp: isFinite(ao5) ? fmtTime(ao5, PEN_NONE) : 'DNF',
      mean, sd, range, ci,
      updatedAt: rec.updatedAt || 0,
    };
  }

  /**
   * 名次比较：
   *   默认（avg 模式）——Ao5 优先，Ao5 无效者排有效成绩之后，其间比单次最好；
   *   single 模式（3bld/4bld/5bld）——先比单次最好，相同再比平均，仍相同并列按姓名。
   */
  function cmpRows(a, b) {
    if (a.rankMode === 'single') {
      const aN = !isFinite(a.best);
      const bN = !isFinite(b.best);
      if (aN !== bN) return aN ? 1 : -1;
      if (!aN && Math.abs(a.best - b.best) > EPS) return a.best - b.best;
      const aBad = !isFinite(a.ao5);
      const bBad = !isFinite(b.ao5);
      if (aBad !== bBad) return aBad ? 1 : -1;
      if (!aBad && Math.abs(a.ao5 - b.ao5) > EPS) return a.ao5 - b.ao5;
      return a.name.localeCompare(b.name, 'zh');
    }
    const aBad = !isFinite(a.ao5);
    const bBad = !isFinite(b.ao5);
    if (aBad !== bBad) return aBad ? 1 : -1;
    if (!aBad && Math.abs(a.ao5 - b.ao5) > EPS) return a.ao5 - b.ao5;
    const aN = !isFinite(a.best);
    const bN = !isFinite(b.best);
    if (aN !== bN) return aN ? 1 : -1;
    if (!aN && Math.abs(a.best - b.best) > EPS) return a.best - b.best;
    return a.name.localeCompare(b.name, 'zh');
  }

  /** 两行是否并列（按各自模式的关键指标均相同） */
  function tied(a, b) {
    if (a.rankMode === 'single') {
      const aN = !isFinite(a.best);
      const bN = !isFinite(b.best);
      if (aN !== bN) return false;
      if (!aN && Math.abs(a.best - b.best) > EPS) return false;
      const aBad = !isFinite(a.ao5);
      const bBad = !isFinite(b.ao5);
      if (aBad !== bBad) return false;
      if (!aBad && Math.abs(a.ao5 - b.ao5) > EPS) return false;
      return true;
    }
    const aBad = !isFinite(a.ao5);
    const bBad = !isFinite(b.ao5);
    if (aBad !== bBad) return false;
    if (!aBad && Math.abs(a.ao5 - b.ao5) > EPS) return false;
    const aN = !isFinite(a.best);
    const bN = !isFinite(b.best);
    if (aN !== bN) return false;
    if (!aN && Math.abs(a.best - b.best) > EPS) return false;
    return true;
  }

  /**
   * 项目排行榜：先比 Ao5（越小越好），相同再比单次最好，仍相同并列。
   * DNF（Ao5 无效）者排在所有有效成绩之后，其间再按单次最好排序。
   * 返回带 rank 的数组（并列采用 1,2,2,4 竞赛排名制）。
   */
  function rankList(comp, eventId) {
    const ev = eventById(eventId);
    const list = (comp.results[eventId] || []).map((r) => stats(r, ev));
    list.sort(cmpRows);
    let prev = null;
    list.forEach((r, i) => {
      r.rank = (prev && tied(r, prev)) ? prev.rank : i + 1;
      prev = r;
    });
    return list;
  }

  /** 某选手在某项目的当前排名信息 */
  function playerEventInfo(comp, eventId, name) {
    return rankList(comp, eventId).find((r) => r.name === name) || null;
  }

  /** 本场比赛出现过的所有选手名（跨项目合并） */
  function compPlayerNames(comp) {
    const set = new Set();
    (comp.events || []).forEach((evId) => {
      (comp.results[evId] || []).forEach((r) => set.add(r.name));
    });
    return set;
  }

  /* ---------------- 工具 ---------------- */
  const fmt2 = (x) => (Math.round(x * 100) / 100).toFixed(2);
  const round2 = (x) => Math.round(x * 100) / 100;

  /* ---------------- 全局选手库（跨比赛聚合） ---------------- */

  /**
   * 聚合全部比赛的全部选手：
   * 每人 { name, comps: [{id,name,date,evId,evName,rank,bestDisp,ao5Disp}],
   *        events: { evId: {best,bestDisp,ao5,ao5Disp,solved,attempts,rounds,medals:{g,s,b}} },
   *        medals: {g,s,b} }
   */
  function allPlayerStats() {
    const players = new Map();
    state.competitions.forEach((comp) => {
      (comp.events || []).forEach((evId) => {
        rankList(comp, evId).forEach((r) => {
          let p = players.get(r.name);
          if (!p) {
            p = { name: r.name, comps: [], events: {}, medals: { g: 0, s: 0, b: 0 } };
            players.set(r.name, p);
          }
          let e = p.events[evId];
          if (!e) {
            e = {
              best: Infinity, bestDisp: 'DNF',
              ao5: Infinity, ao5Disp: 'DNF',
              solved: 0, attempts: 0, rounds: 0,
              medals: { g: 0, s: 0, b: 0 },
            };
            p.events[evId] = e;
          }
          if (r.best < e.best) { e.best = r.best; e.bestDisp = r.bestDisp; }
          if (r.ao5 < e.ao5) { e.ao5 = r.ao5; e.ao5Disp = r.ao5Disp; }
          r.times.forEach((t) => { if (t.pen !== PEN_DNF) e.solved++; e.attempts++; });
          e.rounds++;
          if (r.rank === 1) { e.medals.g++; p.medals.g++; }
          else if (r.rank === 2) { e.medals.s++; p.medals.s++; }
          else if (r.rank === 3) { e.medals.b++; p.medals.b++; }
          p.comps.push({
            id: comp.id, name: comp.name, date: comp.date,
            evId, evName: (eventById(evId) || {}).name || evId,
            rank: r.rank, bestDisp: r.bestDisp, ao5Disp: r.ao5Disp,
          });
        });
      });
    });
    players.forEach((p) => {
      p.comps.sort((a, b) => String(a.date).localeCompare(String(b.date))
        || String(a.name).localeCompare(String(b.name)));
    });
    return [...players.values()];
  }

  const getPlayer = (name) => allPlayerStats().find((p) => p.name === name) || null;

  /**
   * 俱乐部纪录：每个项目历史上的最佳单次与最佳平均（跨全部比赛）。
   * 返回按 EVENTS 默认顺序的数组：
   *   [{ evId, single, avg }]，其中 single / avg 为 null 或
   *   { name, compId, compName, date, times, disp }
   * times = 纪录所在那一轮的完整成绩（详情列用）。
   */
  function clubRecords() {
    return EVENTS.map((ev) => {
      let single = null;
      let avg = null;
      state.competitions.forEach((comp) => {
        (comp.results[ev.id] || []).forEach((rec) => {
          const s = stats(rec, ev);
          if (isFinite(s.best) && (!single || s.best < single.val - EPS)) {
            single = {
              val: s.best, name: rec.name,
              compId: comp.id, compName: comp.name, date: comp.date,
              times: rec.times, disp: s.bestDisp,
            };
          }
          if (isFinite(s.ao5) && (!avg || s.ao5 < avg.val - EPS)) {
            avg = {
              val: s.ao5, name: rec.name,
              compId: comp.id, compName: comp.name, date: comp.date,
              times: rec.times, disp: s.ao5Disp,
            };
          }
        });
      });
      return { evId: ev.id, single, avg };
    });
  }

  /** 某项目全部选手全局排名：mode = 'best'（单次）| 'ao5'（平均），竞赛制并列 */
  function playerRanking(evId, mode) {
    const key = mode === 'best' ? 'best' : 'ao5';
    const rows = allPlayerStats()
      .filter((p) => p.events[evId])
      .map((p) => ({
        name: p.name,
        val: p.events[evId][key],
        disp: p.events[evId][key + 'Disp'],
      }));
    rows.sort((a, b) => {
      const aBad = !isFinite(a.val);
      const bBad = !isFinite(b.val);
      if (aBad !== bBad) return aBad ? 1 : -1;
      if (!aBad && Math.abs(a.val - b.val) > EPS) return a.val - b.val;
      return a.name.localeCompare(b.name, 'zh');
    });
    let prev = null;
    rows.forEach((r, i) => {
      const bothBad = prev && !isFinite(r.val) && !isFinite(prev.val);
      const tie = prev && (bothBad
        || (isFinite(r.val) && isFinite(prev.val) && Math.abs(r.val - prev.val) <= EPS));
      r.rank = tie ? prev.rank : i + 1;
      prev = r;
    });
    return rows;
  }

  window.CubeData = {
    EVENTS, eventById,
    load, save,
    createCompetition, getComp, deleteCompetition,
    endCompetition, reopenCompetition, addEvent, moveEvents, removeEvent,
    parseTime, upsertRecord, deleteRecord,
    stats, rankList, playerEventInfo, compPlayerNames,
    fmtTime, fmt2, round2,
    allPlayerStats, getPlayer, playerRanking, clubRecords,
    state: () => state,
  };
})();
