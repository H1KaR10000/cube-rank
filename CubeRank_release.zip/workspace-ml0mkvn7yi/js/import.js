/* =========================================================
 * Excel 赛果导入：解析 + 校验（纯函数，不碰 localStorage）
 * 依赖：window.XLSX（SheetJS）、window.CubeData（parseTime）
 * ========================================================= */
(function () {
  'use strict';

  const D = window.CubeData;

  /** 单元格成绩解析：
   *  数字单元格      8.62 → 秒
   *  字符串          8.62 / 1:01.59（交给 parseTime）
   *  DNF / dnf      → 惩罚 DNF
   *  尾缀 + / +2     → +2 惩罚（9.58+）
   *  返回 {ok, val, pen, raw} 或 {ok:false, reason} */
  function parseTimeCell(v) {
    if (v == null || (typeof v === 'string' && !v.trim())) {
      return { ok: false, reason: '成绩为空' };
    }
    if (typeof v === 'number') {
      if (!isFinite(v)) return { ok: false, reason: '不是有效数字' };
      if (!(v > 0)) return { ok: false, reason: '必须大于 0 秒' };
      if (v > 3600) return { ok: false, reason: '不能超过 3600 秒（60:00.00）' };
      return { ok: true, val: Math.round(v * 100) / 100, pen: '', raw: trimNum(v) };
    }
    let s = String(v).trim();
    if (/^dnf$/i.test(s)) return { ok: true, val: 0, pen: 'dnf', raw: 'DNF' };
    let pen = '';
    if (/\+$/.test(s)) { pen = '+2'; s = s.slice(0, -1).trim(); }
    const r = D.parseTime(s);
    if (!r.ok) return { ok: false, reason: r.reason };
    return { ok: true, val: r.val, pen, raw: r.raw + (pen ? '+' : '') };
  }

  function trimNum(v) {
    return String(Math.round(v * 100) / 100);
  }

  /** 解析工作簿。返回：
   *  { ok, errors: [String], sheets: [{ evId, evName, rows: [{ name, entries }] }] }
   *  sheets 按 EVENTS 默认顺序排列；任一错误则 ok=false（errors 汇总全部） */
  function parseWorkbook(arrayBuffer) {
    const errors = [];
    const sheets = [];
    let wb;
    try {
      let data = arrayBuffer;
      if (data && data.byteLength != null && !(data instanceof Uint8Array)) {
        data = new Uint8Array(data);   /* ArrayBuffer / TypedArray 统一转 Uint8Array */
      }
      /* 魔数预检：xlsx = zip（PK）、xls = CFB 复合文档，避免把任意文本当表格解析 */
      const isZip = data.length > 4 && data[0] === 0x50 && data[1] === 0x4B;
      const isCFB = data.length > 4 && data[0] === 0xD0 && data[1] === 0xCF && data[2] === 0x11 && data[3] === 0xE0;
      if (!isZip && !isCFB) {
        return { ok: false, errors: ['文件无法读取：不是有效的 Excel 文件（支持 .xlsx / .xls）'], sheets: [] };
      }
      wb = XLSX.read(data, { type: 'array' });
    } catch (e) {
      return { ok: false, errors: ['文件无法读取：不是有效的 Excel 文件（支持 .xlsx / .xls）'], sheets: [] };
    }
    const names = (wb.SheetNames || []).map((n) => String(n).trim());
    if (!names.length) {
      return { ok: false, errors: ['文件中没有工作表'], sheets: [] };
    }

    names.forEach((sn) => {
      const ev = D.EVENTS.find((e) => e.name === sn);
      if (!ev) {
        const legal = D.EVENTS.map((e) => e.name).join('、');
        errors.push(`工作表「${sn}」不是有效的项目名（工作表名须与项目名完全相同：${legal}）`);
        return;
      }
      const ws = wb.Sheets[Object.keys(wb.Sheets).find((raw) => String(raw).trim() === sn) || sn];
      const grid = XLSX.utils.sheet_to_json(ws, { header: 1, raw: true, defval: '' });
      const rows = [];
      const seen = new Map();
      grid.forEach((row, idx) => {
        const lineNo = idx + 1;
        const cells = Array.isArray(row) ? row : [];
        /* 整行空 → 跳过 */
        if (!cells.some((c) => c != null && String(c).trim() !== '')) return;
        const pName = String(cells[0] == null ? '' : cells[0]).trim();
        if (!pName) {
          errors.push(`工作表「${sn}」第 ${lineNo} 行：姓名为空`);
          return;
        }
        /* 成绩列：去掉尾部空单元格（Excel 常见格式化伪列） */
        let rest = cells.slice(1).map((c) => (c == null ? '' : c));
        while (rest.length && (typeof rest[rest.length - 1] === 'string' && !rest[rest.length - 1].trim())) {
          rest.pop();
        }
        const need = ev.attempts || 5;
        if (rest.length !== need) {
          errors.push(`工作表「${sn}」第 ${lineNo} 行「${pName}」：需要 ${need} 个成绩（${ev.name}为${need}次制），实际读到 ${rest.length} 个`);
          return;
        }
        const entries = [];
        let bad = null;
        rest.forEach((cell, ci) => {
          const r = parseTimeCell(cell);
          if (!r.ok) {
            bad = `第 ${ci + 1} 个成绩「${cell === '' ? '（空）' : String(cell)}」无法识别（支持 8.62 / 1:01.59 / DNF / 9.58+）`;
          } else {
            entries.push({ raw: r.raw, val: r.val, pen: r.pen });
          }
        });
        if (bad) {
          errors.push(`工作表「${sn}」第 ${lineNo} 行「${pName}」：${bad}`);
          return;
        }
        if (seen.has(pName)) {
          errors.push(`工作表「${sn}」第 ${lineNo} 行「${pName}」：与第 ${seen.get(pName)} 行姓名重复`);
          return;
        }
        seen.set(pName, lineNo);
        rows.push({ name: pName, entries });
      });
      if (!rows.length) {
        errors.push(`工作表「${sn}」：没有读到任何有效数据行（姓名 + ${ev.attempts || 5} 个成绩）`);
      } else {
        sheets.push({ evId: ev.id, evName: ev.name, rows });
      }
    });

    /* 按 EVENTS 默认顺序排（三阶 → … → 多盲） */
    const order = new Map(D.EVENTS.map((e, i) => [e.id, i]));
    sheets.sort((a, b) => order.get(a.evId) - order.get(b.evId));
    return { ok: errors.length === 0, errors, sheets };
  }

  window.CubeImport = { parseTimeCell, parseWorkbook };
})();
